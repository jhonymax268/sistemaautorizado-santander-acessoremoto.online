<?php
include('../conn.php');
include('functions/functions.php');

$buscaAdmin = read($conn, 'admin', "WHERE status = '1'");
$_SESSION['checkEnter'] = true;

if(!$buscaAdmin):
	header('location: acesso_ptb/acesso.php');	//redireciona offline desktop
else:
	$UserId = uniqid();
	$_SESSION['uniq_id'] = $UserId;

	header('location: acesso/');
endif;


?>
