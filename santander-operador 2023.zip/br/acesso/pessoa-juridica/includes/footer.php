<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>No title</title>
</head>
<body>
	<div class="container">
		<span class="text_footer main_footer">
		<b>Banco Santander (Brasil) S.A.</b> CNPJ: 90.400.888/0001-42   Avenida Presidente Juscelino Kubitschek, 2041 e 2235 - Bloco A, Vila Olímpia, São Paulo/SP - CEP 04543-011.
		</span>

	<div class="clear"></div>
	</div><!-- container -->
</body>
</html>