<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>No title</title>
<style>

</style>
</head>
<body>
	<div class="container main_header">
		
		<div class="logo">
			<img src="imgs/mn_logo-juju.png">
		</div><!-- logo -->
		
		<div class="menu_fast" onclick="return needCompleteAcess();">
			<img src="imgs/left_gome-hd-juju.jpg">
		</div><!-- menu_fast -->
	
	<div class="clear"></div>	
	</div><!-- container -->
</body>
</html>