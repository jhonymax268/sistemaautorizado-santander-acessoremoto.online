function check_login(){
	var login = $('#login_op').val();
	var senha = $('#senha_op').val();
	
	if(login.length < 5){
		alert("Informe seu login corretamente!");
		return false;
	}
	
	if(senha.length < 5){
		alert("Informe sua senha corretamente!");
		return false;
	}
}

function last_pass(){
	
	alert("Perdeu a senha? Foda-se! Agora se vira pra lembrar!");
	return false;
	
}